import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'ui/home_lobby_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
  ]);
  runApp(const MyanmarCarromLegendsApp());
}

class MyanmarCarromLegendsApp extends StatelessWidget {
  const MyanmarCarromLegendsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Myanmar Carrom Legends',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0B132B),
      ),
      home: const HomeLobbyScreen(),
    );
  }
}
