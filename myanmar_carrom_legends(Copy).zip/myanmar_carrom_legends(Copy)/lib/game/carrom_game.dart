import 'dart:async';
import 'dart:math' as math;
import 'package:flame/camera.dart';
import 'package:flame/events.dart';
import 'package:flame_forge2d/flame_forge2d.dart';
import 'package:flutter/foundation.dart';
import '../models/game_models.dart';
import '../network/multiplayer_service.dart';
import '../rules/carrom_rule_engine.dart';
import 'components/board_component.dart';
import 'components/coin_component.dart';
import 'components/striker_component.dart';

class MyanmarCarromGame extends Forge2DGame with PanDetector {
  final MatchConfig matchConfig;
  final MultiplayerService? multiplayerService;
  final Map<String, dynamic>? initialServerSnapshot;

  late final CarromRuleEngine ruleEngine;
  late final ValueNotifier<MatchStateSnapshot> stateNotifier;

  late CarromBoardComponent board;
  late StrikerComponent striker;
  final List<CarromCoinComponent> activeCoins = [];

  final TurnShotReport _currentShotReport = TurnShotReport();
  bool _shotInProgress = false;
  double _baselineSliderRatio = 0.0;
  StreamSubscription<Map<String, dynamic>>? _networkSub;

  bool get isOnlineMatch => multiplayerService != null;

  MyanmarCarromGame({
    required this.matchConfig,
    this.multiplayerService,
    this.initialServerSnapshot,
  }) : super(gravity: Vector2.zero(), zoom: 1.0) {
    ruleEngine = CarromRuleEngine(config: matchConfig);
    stateNotifier = ValueNotifier<MatchStateSnapshot>(_buildSnapshot());
  }

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    camera.viewport = FixedResolutionViewport(
      resolution: Vector2(92.0, 92.0),
    );
    camera.viewfinder.anchor = Anchor.center;
    camera.viewfinder.position = Vector2.zero();
    camera.viewfinder.zoom = 1.0;

    board = CarromBoardComponent();
    await world.add(board);

    striker = StrikerComponent();
    await world.add(striker);

    await _rackNewBoard();

    if (isOnlineMatch) {
      if (initialServerSnapshot != null) {
        _applyAuthoritativeSnapshot(initialServerSnapshot!);
      }
      _networkSub = multiplayerService!.events.listen(_handleServerEvent);
    }
  }

  @override
  void onRemove() {
    _networkSub?.cancel();
    super.onRemove();
  }

  void _handleServerEvent(Map<String, dynamic> event) {
    final type = event['type'] as String? ?? '';
    switch (type) {
      case 'STRIKER_MOVED':
        final x = (event['x'] as num).toDouble();
        final y = (event['y'] as num).toDouble();
        final legal = event['legal'] as bool? ?? true;
        striker.body.setTransform(Vector2(x, y), 0);
        striker.isLegalPlacement = legal;
        break;

      case 'TURN_RESOLVED':
        final outcome = event['shotOutcome'] as Map<String, dynamic>;
        final snapshot = event['snapshot'] as Map<String, dynamic>;
        _playServerKeyframesAndSnap(outcome, snapshot);
        break;

      case 'PLAYER_RECONNECTED':
        final snapshot = event['snapshot'] as Map<String, dynamic>;
        _applyAuthoritativeSnapshot(snapshot);
        break;

      case 'PLAYER_DISCONNECTED':
        final name = event['displayName'] ?? 'Player';
        ruleEngine.lastStatusMessage =
            '$name လိုင်းပြတ်သွားပါသည် — ၄၅ စက္ကန့်အတွင်း ပြန်ဝင်ရန် စောင့်ဆိုင်းနေသည်...';
        _emitStateUpdate();
        break;

      case 'SHOT_REJECTED':
        ruleEngine.lastStatusMessage =
            event['bannerBurmese'] as String? ?? 'ပစ်ချက် ပယ်ချခံရသည်';
        _emitStateUpdate();
        break;
    }
  }

  Future<void> _playServerKeyframesAndSnap(
    Map<String, dynamic> outcome,
    Map<String, dynamic> finalSnapshot,
  ) async {
    _shotInProgress = true;
    _emitStateUpdate();

    final keyframes = (outcome['keyframes'] as List<dynamic>? ?? []);
    for (final frame in keyframes) {
      final fMap = frame as Map<String, dynamic>;
      final sData = fMap['striker'] as Map<String, dynamic>;
      striker.body.setTransform(
        Vector2(
          (sData['x'] as num).toDouble(),
          (sData['y'] as num).toDouble(),
        ),
        0,
      );

      final cList = fMap['coins'] as List<dynamic>;
      for (int i = 0; i < cList.length && i < activeCoins.length; i++) {
        final cData = cList[i] as Map<String, dynamic>;
        final coin = activeCoins[i];
        coin.isPocketed = cData['isPocketed'] as bool;
        coin.body.setTransform(
          Vector2(
            (cData['x'] as num).toDouble(),
            (cData['y'] as num).toDouble(),
          ),
          0,
        );
      }
      await Future<void>.delayed(const Duration(milliseconds: 22));
    }

    _shotInProgress = false;
    _applyAuthoritativeSnapshot(finalSnapshot);
  }

  void _applyAuthoritativeSnapshot(Map<String, dynamic> snap) {
    ruleEngine.currentBoardNumber = snap['currentBoardNumber'] as int? ?? 1;
    ruleEngine.whiteTeamScore = snap['whiteTeamScore'] as int? ?? 0;
    ruleEngine.blackTeamScore = snap['blackTeamScore'] as int? ?? 0;
    ruleEngine.remainingWhite = snap['remainingWhite'] as int? ?? 9;
    ruleEngine.remainingBlack = snap['remainingBlack'] as int? ?? 9;
    ruleEngine.whitePenaltyDebt = snap['whitePenaltyDebt'] as int? ?? 0;
    ruleEngine.blackPenaltyDebt = snap['blackPenaltyDebt'] as int? ?? 0;
    ruleEngine.lastStatusMessage =
        snap['bannerMessage'] as String? ?? ruleEngine.lastStatusMessage;
    ruleEngine.matchOver = snap['matchOver'] as bool? ?? false;
    ruleEngine.matchWinnerText = snap['winnerAnnouncement'] as String?;

    final qStr = snap['queenStatus'] as String? ?? 'ON_BOARD';
    switch (qStr) {
      case 'POCKETED_PENDING_COVER':
        ruleEngine.queenStatus = QueenStatus.pocketedPendingCover;
        break;
      case 'COVERED_BY_WHITE':
        ruleEngine.queenStatus = QueenStatus.coveredByWhite;
        break;
      case 'COVERED_BY_BLACK':
        ruleEngine.queenStatus = QueenStatus.coveredByBlack;
        break;
      default:
        ruleEngine.queenStatus = QueenStatus.onBoard;
    }

    final seatStr = snap['activeSeat'] as String? ?? 'SOUTH';
    final idx = ruleEngine.seats.indexWhere(
      (s) => s.seat.name.toUpperCase() == seatStr,
    );
    if (idx >= 0) {
      ruleEngine.currentSeatIndex = idx;
    }

    final sPos = snap['strikerPos'] as Map<String, dynamic>?;
    if (sPos != null) {
      striker.body.setTransform(
        Vector2(
          (sPos['x'] as num).toDouble(),
          (sPos['y'] as num).toDouble(),
        ),
        0,
      );
      striker.body.linearVelocity.setZero();
    }

    final coinsData = snap['coins'] as List<dynamic>? ?? [];
    for (int i = 0; i < coinsData.length && i < activeCoins.length; i++) {
      final cMap = coinsData[i] as Map<String, dynamic>;
      activeCoins[i].isPocketed = cMap['isPocketed'] as bool;
      activeCoins[i].body.setTransform(
        Vector2(
          (cMap['x'] as num).toDouble(),
          (cMap['y'] as num).toDouble(),
        ),
        0,
      );
      activeCoins[i].body.linearVelocity.setZero();
    }

    _emitStateUpdate();
  }

  Future<void> _rackNewBoard() async {
    for (final c in activeCoins) {
      c.removeFromParent();
    }
    activeCoins.clear();

    final queen = CarromCoinComponent(
      coinType: CoinType.queen,
      initialPosition: Vector2.zero(),
    );
    activeCoins.add(queen);
    await world.add(queen);

    const double d = CarromCoinComponent.coinRadius * 2.04;
    for (int i = 0; i < 6; i++) {
      final angle = i * math.pi / 3;
      final pos = Vector2(math.cos(angle) * d, math.sin(angle) * d);
      final type = (i % 2 == 0) ? CoinType.white : CoinType.black;
      final coin = CarromCoinComponent(coinType: type, initialPosition: pos);
      activeCoins.add(coin);
      await world.add(coin);
    }

    final List<CoinType> outerColors = [
      CoinType.white,
      CoinType.black,
      CoinType.white,
      CoinType.black,
      CoinType.white,
      CoinType.black,
      CoinType.white,
      CoinType.black,
      CoinType.white,
      CoinType.black,
      CoinType.black,
      CoinType.white,
    ];

    for (int i = 0; i < 12; i++) {
      final angle = i * math.pi / 6;
      final radius = (i % 2 == 0) ? d * 2.0 : d * math.sqrt(3.0);
      final pos = Vector2(math.cos(angle) * radius, math.sin(angle) * radius);
      final coin = CarromCoinComponent(
        coinType: outerColors[i],
        initialPosition: pos,
      );
      activeCoins.add(coin);
      await world.add(coin);
    }

    _positionStrikerForActiveSeat(0.0);
    _emitStateUpdate();
  }

  void updateStrikerBaselineSlider(double sliderRatio) {
    if (_shotInProgress || ruleEngine.matchOver) return;
    _baselineSliderRatio = sliderRatio.clamp(-1.0, 1.0);
    _positionStrikerForActiveSeat(_baselineSliderRatio);
    if (isOnlineMatch) {
      multiplayerService!.sendStrikerSlide(_baselineSliderRatio);
    }
    _emitStateUpdate();
  }

  void _positionStrikerForActiveSeat(double ratio) {
    const double span = CarromBoardComponent.baselineHalfSpan;
    const double offset = CarromBoardComponent.baselineOffset;
    final double coord = ratio * span;

    Vector2 target;
    switch (ruleEngine.activePlayer.seat) {
      case BoardSeat.south:
        target = Vector2(coord, offset);
        break;
      case BoardSeat.north:
        target = Vector2(-coord, -offset);
        break;
      case BoardSeat.east:
        target = Vector2(offset, -coord);
        break;
      case BoardSeat.west:
        target = Vector2(-offset, coord);
        break;
    }

    striker.body.setTransform(target, 0);
    striker.body.linearVelocity.setZero();
    striker.body.angularVelocity = 0;
    striker.isLegalPlacement = _isStrikerPositionClearOfCoins(target);
  }

  bool _isStrikerPositionClearOfCoins(Vector2 strikerPos) {
    const double minClearDistance =
        StrikerComponent.strikerRadius + CarromCoinComponent.coinRadius + 0.12;
    for (final coin in activeCoins) {
      if (!coin.isPocketed &&
          coin.body.position.distanceTo(strikerPos) < minClearDistance) {
        return false;
      }
    }
    return true;
  }

  @override
  void onPanStart(DragStartInfo info) {
    if (_shotInProgress || ruleEngine.matchOver) return;
    final worldTouch = screenToWorld(info.eventPosition.widget);
    if (worldTouch.distanceTo(striker.body.position) <= 8.5) {
      striker.isAiming = true;
      striker.aimDragVector = Vector2.zero();
    }
  }

  @override
  void onPanUpdate(DragUpdateInfo info) {
    if (!striker.isAiming || _shotInProgress) return;
    final worldTouch = screenToWorld(info.eventPosition.widget);
    striker.aimDragVector = worldTouch - striker.body.position;
  }

  @override
  void onPanEnd(DragEndInfo info) {
    if (!striker.isAiming || _shotInProgress) return;
    final drag = striker.aimDragVector;
    striker.isAiming = false;
    striker.aimDragVector = null;

    if (drag == null || drag.length < 1.1) return;

    if (!striker.isLegalPlacement) {
      ruleEngine.lastStatusMessage =
          'Striker သည် အခြားဇယ်နှင့် ထိနေပါသည် — Slider ဖြင့် နေရာရွှေ့ပါ!';
      _emitStateUpdate();
      return;
    }

    if (isOnlineMatch) {
      multiplayerService!.sendExecuteShot(
        sliderRatio: _baselineSliderRatio,
        dragX: drag.x,
        dragY: drag.y,
      );
      return;
    }

    final pullStrength = (drag.length / 14.0).clamp(0.08, 1.0);
    final impulseDirection = -drag.normalized();
    final velocity =
        impulseDirection * (pullStrength * StrikerComponent.maxImpulseSpeed);

    _currentShotReport.reset();
    _shotInProgress = true;
    striker.body.linearVelocity = velocity;
    _emitStateUpdate();
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (isOnlineMatch || !_shotInProgress) return;

    _checkPocketDrops();

    if (_areAllBodiesStopped()) {
      _shotInProgress = false;
      _resolveCompletedTurn();
    }
  }

  void _checkPocketDrops() {
    const double captureDist = CarromBoardComponent.pocketRadius - 0.30;

    for (final coin in activeCoins) {
      if (coin.isPocketed) continue;
      for (final pocket in CarromBoardComponent.pocketCenters) {
        if (coin.body.position.distanceTo(pocket) <= captureDist) {
          coin.isPocketed = true;
          coin.body.linearVelocity.setZero();
          coin.body.setTransform(Vector2(200, 200), 0);
          if (coin.coinType == CoinType.white) {
            _currentShotReport.whitePocketed += 1;
          } else if (coin.coinType == CoinType.black) {
            _currentShotReport.blackPocketed += 1;
          } else {
            _currentShotReport.queenPocketedThisShot = true;
          }
          break;
        }
      }
    }

    if (!_currentShotReport.strikerPocketed) {
      for (final pocket in CarromBoardComponent.pocketCenters) {
        if (striker.body.position.distanceTo(pocket) <= captureDist) {
          _currentShotReport.strikerPocketed = true;
          striker.body.linearVelocity.setZero();
          striker.body.setTransform(Vector2(-200, -200), 0);
          break;
        }
      }
    }
  }

  bool _areAllBodiesStopped() {
    if (striker.body.linearVelocity.length > 0.05) return false;
    for (final coin in activeCoins) {
      if (!coin.isPocketed && coin.body.linearVelocity.length > 0.05) {
        return false;
      }
    }
    return true;
  }

  Future<void> _resolveCompletedTurn() async {
    final result = ruleEngine.evaluateShot(_currentShotReport);

    if (result.boardFinished) {
      if (!ruleEngine.matchOver) {
        ruleEngine.resetForNewBoard();
        await _rackNewBoard();
      }
      _emitStateUpdate();
      return;
    }

    if (result.returnQueenToCenter) {
      final queen =
          activeCoins.firstWhere((c) => c.coinType == CoinType.queen);
      queen.isPocketed = false;
      queen.body.setTransform(_findNonOverlappingCenterSpot(), 0);
      queen.body.linearVelocity.setZero();
    }

    int whiteToRestore = result.whitePenaltyCoinsToReturn;
    for (final coin in activeCoins) {
      if (whiteToRestore <= 0) break;
      if (coin.isPocketed && coin.coinType == CoinType.white) {
        coin.isPocketed = false;
        coin.body.setTransform(_findNonOverlappingCenterSpot(), 0);
        coin.body.linearVelocity.setZero();
        whiteToRestore--;
      }
    }

    int blackToRestore = result.blackPenaltyCoinsToReturn;
    for (final coin in activeCoins) {
      if (blackToRestore <= 0) break;
      if (coin.isPocketed && coin.coinType == CoinType.black) {
        coin.isPocketed = false;
        coin.body.setTransform(_findNonOverlappingCenterSpot(), 0);
        coin.body.linearVelocity.setZero();
        blackToRestore--;
      }
    }

    _baselineSliderRatio = 0.0;
    _positionStrikerForActiveSeat(0.0);
    _emitStateUpdate();
  }

  Vector2 _findNonOverlappingCenterSpot() {
    const double minSeparation = CarromCoinComponent.coinRadius * 2.15;
    if (_isSpotFree(Vector2.zero(), minSeparation)) {
      return Vector2.zero();
    }
    for (double radius = 1.8; radius <= 18.0; radius += 1.6) {
      for (int i = 0; i < 16; i++) {
        final angle = i * (2 * math.pi / 16);
        final candidate = Vector2(
          math.cos(angle) * radius,
          math.sin(angle) * radius,
        );
        if (_isSpotFree(candidate, minSeparation)) {
          return candidate;
        }
      }
    }
    return Vector2.zero();
  }

  bool _isSpotFree(Vector2 candidate, double minSeparation) {
    for (final coin in activeCoins) {
      if (!coin.isPocketed &&
          coin.body.position.distanceTo(candidate) < minSeparation) {
        return false;
      }
    }
    return true;
  }

  MatchStateSnapshot _buildSnapshot() {
    return MatchStateSnapshot(
      mode: matchConfig.mode,
      currentBoardNumber: ruleEngine.currentBoardNumber,
      whiteTeamScore: ruleEngine.whiteTeamScore,
      blackTeamScore: ruleEngine.blackTeamScore,
      remainingWhiteCoins: ruleEngine.remainingWhite,
      remainingBlackCoins: ruleEngine.remainingBlack,
      whiteDebt: ruleEngine.whitePenaltyDebt,
      blackDebt: ruleEngine.blackPenaltyDebt,
      queenStatus: ruleEngine.queenStatus,
      activePlayer: ruleEngine.activePlayer,
      bannerMessage: ruleEngine.lastStatusMessage,
      isStrikerMoving: _shotInProgress,
      isPositioningConstrained: false,
      matchComplete: ruleEngine.matchOver,
      winnerAnnouncement: ruleEngine.matchWinnerText,
    );
  }

  void _emitStateUpdate() {
    stateNotifier.value = _buildSnapshot();
  }
}
