import 'package:flame_forge2d/flame_forge2d.dart';
import 'package:flutter/material.dart';

class StrikerComponent extends BodyComponent {
  static const double strikerRadius = 2.05;
  static const double maxImpulseSpeed = 145.0;

  Vector2? aimDragVector;
  bool isLegalPlacement = true;
  bool isAiming = false;

  @override
  Body createBody() {
    final bodyDef = BodyDef(
      type: BodyType.dynamic,
      position: Vector2(0, 26.5),
      bullet: true,
      linearDamping: 1.95,
      angularDamping: 2.5,
    );

    final strikerBody = world.createBody(bodyDef);
    final shape = CircleShape()..radius = strikerRadius;

    strikerBody.createFixture(
      FixtureDef(
        shape,
        density: 1.35,
        restitution: 0.82,
        friction: 0.05,
      ),
    );
    return strikerBody;
  }

  @override
  void update(double dt) {
    super.update(dt);
    final speed = body.linearVelocity.length;
    if (speed > 0 && speed < 0.45) {
      body.linearVelocity.setZero();
      body.angularVelocity = 0;
    } else if (speed >= 0.45 && speed < 4.5) {
      body.linearVelocity.scale(0.97);
    }
  }

  @override
  void render(Canvas canvas) {
    if (isAiming && aimDragVector != null && aimDragVector!.length > 0.8) {
      final pullDistance = aimDragVector!.length.clamp(0.0, 14.0);
      final powerRatio = pullDistance / 14.0;
      final shotDir = -aimDragVector!.normalized();

      final guideLength = 8.0 + (powerRatio * 20.0);
      final guidePaint = Paint()
        ..color = Color.lerp(
          const Color(0xFF00E676),
          const Color(0xFFFF3D00),
          powerRatio,
        )!
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.35;

      canvas.drawLine(
        Offset.zero,
        Offset(shotDir.x * guideLength, shotDir.y * guideLength),
        guidePaint,
      );

      canvas.drawCircle(
        Offset.zero,
        strikerRadius + (powerRatio * 2.5),
        Paint()
          ..color = guidePaint.color.withOpacity(0.35)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.25,
      );
    }

    final mainColor = isLegalPlacement
        ? const Color(0xFF00B4D8)
        : const Color(0xFFE63946);

    canvas.drawCircle(
      Offset.zero,
      strikerRadius,
      Paint()..color = const Color(0xFFFFFDF7),
    );

    canvas.drawCircle(
      Offset.zero,
      strikerRadius * 0.78,
      Paint()..color = mainColor,
    );

    canvas.drawCircle(
      Offset.zero,
      strikerRadius * 0.42,
      Paint()
        ..color = const Color(0xFFFFD700)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.25,
    );
  }
}
