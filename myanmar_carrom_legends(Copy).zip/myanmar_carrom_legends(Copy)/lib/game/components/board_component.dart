import 'dart:math' as math;
import 'package:flame/components.dart';
import 'package:flame_forge2d/flame_forge2d.dart';
import 'package:flutter/material.dart';

class CarromBoardComponent extends BodyComponent {
  static const double halfBoard = 37.0;
  static const double pocketOffset = 33.8;
  static const double pocketRadius = 2.25;
  static const double baselineOffset = 26.5;
  static const double baselineHalfSpan = 18.5;
  static const double baselineCircleRadius = 1.55;

  static final List<Vector2> pocketCenters = [
    Vector2(-pocketOffset, -pocketOffset),
    Vector2(pocketOffset, -pocketOffset),
    Vector2(pocketOffset, pocketOffset),
    Vector2(-pocketOffset, pocketOffset),
  ];

  @override
  Body createBody() {
    final bodyDef = BodyDef(
      type: BodyType.static,
      position: Vector2.zero(),
    );
    final wallBody = world.createBody(bodyDef);

    final corners = [
      Vector2(-halfBoard, -halfBoard),
      Vector2(halfBoard, -halfBoard),
      Vector2(halfBoard, halfBoard),
      Vector2(-halfBoard, halfBoard),
    ];

    for (int i = 0; i < 4; i++) {
      final shape = EdgeShape()
        ..set(corners[i], corners[(i + 1) % 4]);
      wallBody.createFixture(
        FixtureDef(
          shape,
          restitution: 0.78,
          friction: 0.08,
        ),
      );
    }
    return wallBody;
  }

  @override
  void render(Canvas canvas) {
    final frameRect = Rect.fromCenter(
      center: Offset.zero,
      width: (halfBoard + 5.5) * 2,
      height: (halfBoard + 5.5) * 2,
    );
    final frameRRect = RRect.fromRectAndRadius(
      frameRect,
      const Radius.circular(4.2),
    );
    canvas.drawRRect(
      frameRRect,
      Paint()..color = const Color(0xFF28150B),
    );

    canvas.drawRRect(
      frameRRect.deflate(0.8),
      Paint()
        ..color = const Color(0xFFD4AF37)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.45,
    );

    final surfaceRect = Rect.fromCenter(
      center: Offset.zero,
      width: halfBoard * 2,
      height: halfBoard * 2,
    );
    canvas.drawRect(
      surfaceRect,
      Paint()..color = const Color(0xFFEED9B3),
    );

    final linePaint = Paint()
      ..color = const Color(0xFF3E2723)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.25;

    final crimsonFill = Paint()
      ..color = const Color(0xFFB71C1C)
      ..style = PaintingStyle.fill;

    canvas.drawCircle(Offset.zero, 6.3, linePaint);
    canvas.drawCircle(
      Offset.zero,
      1.6,
      Paint()
        ..color = const Color(0xFFB71C1C).withOpacity(0.25)
        ..style = PaintingStyle.fill,
    );
    canvas.drawCircle(Offset.zero, 1.55, linePaint);

    for (int i = 0; i < 8; i++) {
      final angle = i * math.pi / 4;
      final outer = Offset(math.cos(angle) * 6.3, math.sin(angle) * 6.3);
      canvas.drawLine(Offset.zero, outer, linePaint);
    }

    _drawBaseline(canvas, linePaint, crimsonFill, isHorizontal: true, offset: baselineOffset);
    _drawBaseline(canvas, linePaint, crimsonFill, isHorizontal: true, offset: -baselineOffset);
    _drawBaseline(canvas, linePaint, crimsonFill, isHorizontal: false, offset: baselineOffset);
    _drawBaseline(canvas, linePaint, crimsonFill, isHorizontal: false, offset: -baselineOffset);

    for (final pocket in pocketCenters) {
      final center = Offset(pocket.x, pocket.y);
      canvas.drawCircle(
        center,
        pocketRadius + 0.35,
        Paint()
          ..color = const Color(0xFFD4AF37)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 0.3,
      );
      canvas.drawCircle(
        center,
        pocketRadius,
        Paint()..color = const Color(0xFF140D09),
      );
    }
  }

  void _drawBaseline(
    Canvas canvas,
    Paint linePaint,
    Paint circleFill, {
    required bool isHorizontal,
    required double offset,
  }) {
    const double gap = 1.55;
    final sign = offset.sign;
    final innerLine = offset - sign * gap;
    final outerLine = offset + sign * gap;

    if (isHorizontal) {
      canvas.drawLine(
        Offset(-baselineHalfSpan, innerLine),
        Offset(baselineHalfSpan, innerLine),
        linePaint,
      );
      canvas.drawLine(
        Offset(-baselineHalfSpan, outerLine),
        Offset(baselineHalfSpan, outerLine),
        linePaint,
      );
      for (final x in [-baselineHalfSpan, baselineHalfSpan]) {
        canvas.drawCircle(Offset(x, offset), baselineCircleRadius, circleFill);
        canvas.drawCircle(Offset(x, offset), baselineCircleRadius, linePaint);
      }
    } else {
      canvas.drawLine(
        Offset(innerLine, -baselineHalfSpan),
        Offset(innerLine, baselineHalfSpan),
        linePaint,
      );
      canvas.drawLine(
        Offset(outerLine, -baselineHalfSpan),
        Offset(outerLine, baselineHalfSpan),
        linePaint,
      );
      for (final y in [-baselineHalfSpan, baselineHalfSpan]) {
        canvas.drawCircle(Offset(offset, y), baselineCircleRadius, circleFill);
        canvas.drawCircle(Offset(offset, y), baselineCircleRadius, linePaint);
      }
    }
  }
}
