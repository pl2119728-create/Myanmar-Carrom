import 'package:flame_forge2d/flame_forge2d.dart';
import 'package:flutter/material.dart';
import '../../models/game_models.dart';

class CarromCoinComponent extends BodyComponent {
  static const double coinRadius = 1.55;
  static const double stopVelocityThreshold = 0.45;

  final CoinType coinType;
  final Vector2 initialPosition;
  bool isPocketed = false;

  CarromCoinComponent({
    required this.coinType,
    required this.initialPosition,
  });

  @override
  Body createBody() {
    final bodyDef = BodyDef(
      type: BodyType.dynamic,
      position: initialPosition.clone(),
      bullet: true,
      linearDamping: 2.15,
      angularDamping: 2.8,
    );

    final coinBody = world.createBody(bodyDef);
    final shape = CircleShape()..radius = coinRadius;

    coinBody.createFixture(
      FixtureDef(
        shape,
        density: 0.75,
        restitution: 0.86,
        friction: 0.06,
      ),
    );
    return coinBody;
  }

  @override
  void update(double dt) {
    super.update(dt);
    if (isPocketed) return;

    final speed = body.linearVelocity.length;
    if (speed > 0 && speed < stopVelocityThreshold) {
      body.linearVelocity.setZero();
      body.angularVelocity = 0;
    } else if (speed >= stopVelocityThreshold && speed < 4.5) {
      body.linearVelocity.scale(0.97);
    }
  }

  @override
  void render(Canvas canvas) {
    if (isPocketed) return;

    final Color baseColor;
    final Color ringColor;

    switch (coinType) {
      case CoinType.white:
        baseColor = const Color(0xFFFFF8E7);
        ringColor = const Color(0xFFD4AF37);
        break;
      case CoinType.black:
        baseColor = const Color(0xFF1F242D);
        ringColor = const Color(0xFF90A4AE);
        break;
      case CoinType.queen:
        baseColor = const Color(0xFFC62828);
        ringColor = const Color(0xFFFFD700);
        break;
    }

    canvas.drawCircle(
      Offset.zero,
      coinRadius,
      Paint()..color = baseColor,
    );

    canvas.drawCircle(
      Offset.zero,
      coinRadius - 0.1,
      Paint()
        ..color = Colors.black.withOpacity(0.45)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.18,
    );

    canvas.drawCircle(
      Offset.zero,
      coinRadius * 0.62,
      Paint()
        ..color = ringColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = 0.22,
    );

    if (coinType == CoinType.queen) {
      canvas.drawCircle(
        Offset.zero,
        coinRadius * 0.28,
        Paint()..color = const Color(0xFFFFD700),
      );
    }
  }
}
