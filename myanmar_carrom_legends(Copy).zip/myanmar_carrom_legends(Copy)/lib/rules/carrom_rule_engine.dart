import 'dart:math' as math;
import '../models/game_models.dart';

class CarromRuleEngine {
  final MatchConfig config;
  late final List<PlayerSeatConfig> seats;

  int currentSeatIndex = 0;
  int currentBoardNumber = 1;

  int whiteTeamScore = 0;
  int blackTeamScore = 0;

  int remainingWhite = 9;
  int remainingBlack = 9;

  int whitePenaltyDebt = 0;
  int blackPenaltyDebt = 0;

  QueenStatus queenStatus = QueenStatus.onBoard;
  String lastStatusMessage = 'စတင်ကစားနိုင်ပါပြီ - Striker ကို နေရာချပြီး ပစ်ပါ';
  bool matchOver = false;
  String? matchWinnerText;

  CarromRuleEngine({required this.config}) {
    _initializeSeats();
  }

  void _initializeSeats() {
    if (config.mode == BattleMode.duel1v1) {
      seats = const [
        PlayerSeatConfig(
          playerIndex: 0,
          name: 'ကစားသမား ၁ (အဖြူ)',
          seat: BoardSeat.south,
          assignedColor: CoinType.white,
          teamId: 0,
        ),
        PlayerSeatConfig(
          playerIndex: 1,
          name: 'ကစားသမား ၂ (အမည်း)',
          seat: BoardSeat.north,
          assignedColor: CoinType.black,
          teamId: 1,
        ),
      ];
    } else {
      seats = const [
        PlayerSeatConfig(
          playerIndex: 0,
          name: 'အသင်း A - ၁ (အဖြူ)',
          seat: BoardSeat.south,
          assignedColor: CoinType.white,
          teamId: 0,
        ),
        PlayerSeatConfig(
          playerIndex: 1,
          name: 'အသင်း B - ၁ (အမည်း)',
          seat: BoardSeat.east,
          assignedColor: CoinType.black,
          teamId: 1,
        ),
        PlayerSeatConfig(
          playerIndex: 2,
          name: 'အသင်း A - ၂ (အဖြူ)',
          seat: BoardSeat.north,
          assignedColor: CoinType.white,
          teamId: 0,
        ),
        PlayerSeatConfig(
          playerIndex: 3,
          name: 'အသင်း B - ၂ (အမည်း)',
          seat: BoardSeat.west,
          assignedColor: CoinType.black,
          teamId: 1,
        ),
      ];
    }
  }

  PlayerSeatConfig get activePlayer => seats[currentSeatIndex];

  void resetForNewBoard() {
    remainingWhite = 9;
    remainingBlack = 9;
    whitePenaltyDebt = 0;
    blackPenaltyDebt = 0;
    queenStatus = QueenStatus.onBoard;
    currentSeatIndex = (currentBoardNumber - 1) % seats.length;
    lastStatusMessage =
        'ပွဲစဉ် ($currentBoardNumber) စတင်ပြီ — ${activePlayer.name} အလှည့်';
  }

  TurnEvaluationResult evaluateShot(TurnShotReport report) {
    final player = activePlayer;
    final isWhite = player.assignedColor == CoinType.white;

    final int ownPocketed = isWhite ? report.whitePocketed : report.blackPocketed;
    final int oppPocketed = isWhite ? report.blackPocketed : report.whitePocketed;

    remainingWhite = math.max(0, remainingWhite - report.whitePocketed);
    remainingBlack = math.max(0, remainingBlack - report.blackPocketed);

    bool returnQueen = false;
    bool keepTurn = false;
    int penaltyToReturnOwn = 0;
    List<String> notes = [];

    if (report.queenPocketedThisShot) {
      if (report.strikerPocketed) {
        returnQueen = true;
        queenStatus = QueenStatus.onBoard;
        notes.add('Foul! ဘုရင်မ ပြန်ထွက်မည်');
      } else if (ownPocketed > 0) {
        queenStatus =
            isWhite ? QueenStatus.coveredByWhite : QueenStatus.coveredByBlack;
        keepTurn = true;
        notes.add('ဘုရင်မ အောင်မြင်စွာ Cover လုပ်နိုင်သည်! (+3 Bonus အခွင့်အရေး)');
      } else {
        queenStatus = QueenStatus.pocketedPendingCover;
        keepTurn = true;
        notes.add('ဘုရင်မ ဝင်သွားပြီ — နောက်တစ်ချက်တွင် မိမိဇယ်ဝင်အောင်ပစ်ပြီး Cover လုပ်ပါ!');
      }
    } else if (queenStatus == QueenStatus.pocketedPendingCover) {
      if (!report.strikerPocketed && ownPocketed > 0) {
        queenStatus =
            isWhite ? QueenStatus.coveredByWhite : QueenStatus.coveredByBlack;
        keepTurn = true;
        notes.add('ဘုရင်မ Cover အောင်မြင်သည်!');
      } else {
        returnQueen = true;
        queenStatus = QueenStatus.onBoard;
        notes.add('ဘုရင်မ Cover မအောင်မြင်ပါ — ဗဟိုသို့ ပြန်ထားမည်');
      }
    }

    if (report.strikerPocketed) {
      penaltyToReturnOwn += 1;
      keepTurn = false;
      notes.add('Striker ကျင်းဝင်သွားသည် (Foul - ဒဏ်ကြေး ဇယ် ၁ လုံးပြန်တင်ရမည်)');
    } else if (!report.queenPocketedThisShot &&
        queenStatus != QueenStatus.pocketedPendingCover) {
      if (ownPocketed > 0) {
        keepTurn = true;
        notes.add('မိမိဇယ် ($ownPocketed) လုံး ဝင်သည် — ဆက်ပစ်ပါ');
      } else {
        keepTurn = false;
        if (oppPocketed > 0) {
          notes.add('ပြိုင်ဘက်ဇယ် ဝင်သွားသည် — အလှည့်ပြောင်းမည်');
        } else {
          notes.add('ဇယ်မဝင်ပါ — အလှည့်ပြောင်းမည်');
        }
      }
    }

    int actualWhiteReturned = 0;
    int actualBlackReturned = 0;

    if (isWhite) {
      int totalOwed = penaltyToReturnOwn + whitePenaltyDebt;
      int pocketedAvailable = 9 - remainingWhite;
      if (totalOwed > 0 && pocketedAvailable > 0) {
        actualWhiteReturned = math.min(totalOwed, pocketedAvailable);
        remainingWhite += actualWhiteReturned;
        whitePenaltyDebt = totalOwed - actualWhiteReturned;
      } else {
        whitePenaltyDebt = totalOwed;
      }
    } else {
      int totalOwed = penaltyToReturnOwn + blackPenaltyDebt;
      int pocketedAvailable = 9 - remainingBlack;
      if (totalOwed > 0 && pocketedAvailable > 0) {
        actualBlackReturned = math.min(totalOwed, pocketedAvailable);
        remainingBlack += actualBlackReturned;
        blackPenaltyDebt = totalOwed - actualBlackReturned;
      } else {
        blackPenaltyDebt = totalOwed;
      }
    }

    if ((remainingWhite == 0 || remainingBlack == 0) &&
        (queenStatus == QueenStatus.onBoard ||
            queenStatus == QueenStatus.pocketedPendingCover)) {
      if (remainingWhite == 0 && isWhite) {
        return _concludeBoard(
          winningTeam: 1,
          reason: 'ဘုရင်မ မဝင်ဘဲ အဖြူဇယ်ကုန်သွားသဖြင့် အမည်းအသင်း ပွဲစဉ်အနိုင်ရသည်!',
        );
      } else if (remainingBlack == 0 && !isWhite) {
        return _concludeBoard(
          winningTeam: 0,
          reason: 'ဘုရင်မ မဝင်ဘဲ အမည်းဇယ်ကုန်သွားသဖြင့် အဖြူအသင်း ပွဲစဉ်အနိုင်ရသည်!',
        );
      }
    }

    if (remainingWhite == 0) {
      return _concludeBoard(
        winningTeam: 0,
        reason: 'အဖြူအသင်း ဇယ်အားလုံးဝင်ပြီး ပွဲစဉ် ($currentBoardNumber) အနိုင်ရသည်!',
      );
    }
    if (remainingBlack == 0) {
      return _concludeBoard(
        winningTeam: 1,
        reason: 'အမည်းအသင်း ဇယ်အားလုံးဝင်ပြီး ပွဲစဉ် ($currentBoardNumber) အနိုင်ရသည်!',
      );
    }

    if (!keepTurn) {
      currentSeatIndex = (currentSeatIndex + 1) % seats.length;
    }

    lastStatusMessage = notes.join(' • ');

    return TurnEvaluationResult(
      keepTurn: keepTurn,
      returnQueenToCenter: returnQueen,
      whitePenaltyCoinsToReturn: actualWhiteReturned,
      blackPenaltyCoinsToReturn: actualBlackReturned,
      boardFinished: false,
      burmeseText: lastStatusMessage,
    );
  }

  TurnEvaluationResult _concludeBoard({
    required int winningTeam,
    required String reason,
  }) {
    int opponentRemaining =
        winningTeam == 0 ? remainingBlack : remainingWhite;
    opponentRemaining = math.max(1, opponentRemaining);

    int points = opponentRemaining;
    final bool winnerCoveredQueen =
        (winningTeam == 0 && queenStatus == QueenStatus.coveredByWhite) ||
        (winningTeam == 1 && queenStatus == QueenStatus.coveredByBlack);

    final int currentWinnerMatchScore =
        winningTeam == 0 ? whiteTeamScore : blackTeamScore;
    if (winnerCoveredQueen && currentWinnerMatchScore < 22) {
      points += 3;
    }

    points = math.min(5, points);

    if (winningTeam == 0) {
      whiteTeamScore += points;
    } else {
      blackTeamScore += points;
    }

    if (whiteTeamScore >= config.targetPoints ||
        blackTeamScore >= config.targetPoints ||
        currentBoardNumber >= config.maxBoards) {
      matchOver = true;
      if (whiteTeamScore > blackTeamScore) {
        matchWinnerText =
            'အဖြူအသင်း အနိုင်ရရှိပါသည်! ($whiteTeamScore - $blackTeamScore)';
      } else if (blackTeamScore > whiteTeamScore) {
        matchWinnerText =
            'အမည်းအသင်း အနိုင်ရရှိပါသည်! ($blackTeamScore - $whiteTeamScore)';
      } else {
        matchWinnerText = 'ပွဲစဉ် သရေကျပါသည်! ($whiteTeamScore - $blackTeamScore)';
      }
    } else {
      currentBoardNumber += 1;
    }

    lastStatusMessage = '$reason (+$points မှတ်)';

    return TurnEvaluationResult(
      keepTurn: false,
      returnQueenToCenter: false,
      boardFinished: true,
      winningTeamId: winningTeam,
      pointsAwarded: points,
      burmeseText: lastStatusMessage,
    );
  }
}
