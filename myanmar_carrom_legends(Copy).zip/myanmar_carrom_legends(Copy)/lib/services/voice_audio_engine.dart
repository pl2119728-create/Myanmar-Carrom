import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import '../models/phase3_models.dart';

class VoiceAudioEngine {
  static final VoiceAudioEngine instance = VoiceAudioEngine._internal();
  VoiceAudioEngine._internal();

  final AudioPlayer _audioPlayer = AudioPlayer();
  final FlutterTts _tts = FlutterTts();
  final Set<String> _playedEventIds = {};
  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;
    _initialized = true;
    try {
      await _tts.setLanguage('my-MM');
    } catch (_) {}
  }

  Future<void> playStickerAudio({
    required VoiceStickerModel sticker,
    required PlayerVoiceSettingsModel settings,
    required String senderId,
    required String myUserId,
    String? eventId,
    String? overrideGender,
    String serverBaseHttp = 'http://10.0.2.2:8080',
  }) async {
    await init();

    if (eventId != null) {
      if (_playedEventIds.contains(eventId)) return;
      _playedEventIds.add(eventId);
      if (_playedEventIds.length > 200) {
        _playedEventIds.remove(_playedEventIds.first);
      }
    }

    if (settings.muteAll) return;
    if (senderId != myUserId) {
      if (!settings.opponentVoiceEnabled) return;
      if (settings.mutedPlayerIds.contains(senderId)) return;
    }

    final effectiveVolume =
        (settings.masterVolume * settings.voiceStickerVolume).clamp(0.0, 1.0);
    if (effectiveVolume <= 0.01) return;

    final gender = overrideGender ?? settings.preferredGender;
    final relativeUrl =
        gender == 'FEMALE' ? sticker.cdnAudioFemale : sticker.cdnAudioMale;

    try {
      final dir = await getTemporaryDirectory();
      final cacheFile = File('${dir.path}/${sticker.id}_$gender.ogg');
      if (await cacheFile.exists()) {
        await _audioPlayer.setVolume(effectiveVolume);
        await _audioPlayer.play(DeviceFileSource(cacheFile.path));
        return;
      }

      if (relativeUrl.isNotEmpty) {
        final uri = Uri.parse(
          relativeUrl.startsWith('http') ? relativeUrl : '$serverBaseHttp$relativeUrl',
        );
        final response = await http.get(uri).timeout(const Duration(milliseconds: 900));
        if (response.statusCode == 200 && response.bodyBytes.isNotEmpty) {
          await cacheFile.writeAsBytes(response.bodyBytes);
          await _audioPlayer.setVolume(effectiveVolume);
          await _audioPlayer.play(DeviceFileSource(cacheFile.path));
          return;
        }
      }
    } catch (_) {}

    try {
      final pitch = gender == 'FEMALE' ? sticker.pitchFemale : sticker.pitchMale;
      await _tts.setVolume(effectiveVolume);
      await _tts.setPitch(pitch);
      await _tts.setSpeechRate(sticker.rate);
      await _tts.speak(sticker.burmeseText);
    } catch (_) {}
  }
}
