import 'package:flame/game.dart';
import 'package:flutter/material.dart';
import '../game/carrom_game.dart';
import '../models/game_models.dart';
import '../models/phase3_models.dart';
import '../network/multiplayer_service.dart';
import 'phase3_social_and_voice_sheets.dart';

class MatchScreen extends StatefulWidget {
  final MatchConfig config;
  final MultiplayerService mpService;
  final Map<String, dynamic>? initialServerSnapshot;
  final bool isOnline;

  const MatchScreen({
    super.key,
    required this.config,
    required this.mpService,
    this.initialServerSnapshot,
    this.isOnline = false,
  });

  @override
  State<MatchScreen> createState() => _MatchScreenState();
}

class _MatchScreenState extends State<MatchScreen> {
  late MyanmarCarromGame _game;
  double _sliderValue = 0.0;
  bool _showStickerDrawer = false;
  QueenStatus _prevQueenStatus = QueenStatus.onBoard;

  @override
  void initState() {
    super.initState();
    _game = MyanmarCarromGame(
      matchConfig: widget.config,
      multiplayerService: widget.isOnline ? widget.mpService : null,
      initialServerSnapshot: widget.initialServerSnapshot,
    );
    _game.stateNotifier.addListener(_checkLocalAutoVoiceTriggers);
  }

  @override
  void dispose() {
    _game.stateNotifier.removeListener(_checkLocalAutoVoiceTriggers);
    super.dispose();
  }

  void _checkLocalAutoVoiceTriggers() {
    if (widget.isOnline) return;
    final state = _game.stateNotifier.value;
    final settings = widget.mpService.voiceSettings.value;
    if (!settings.autoVoiceEnabled) return;

    final stickers = widget.mpService.voiceStickers.value;
    if (stickers.isEmpty) return;

    if (state.queenStatus != _prevQueenStatus) {
      _prevQueenStatus = state.queenStatus;
      if (state.queenStatus == QueenStatus.pocketedPendingCover ||
          state.queenStatus == QueenStatus.coveredByWhite ||
          state.queenStatus == QueenStatus.coveredByBlack) {
        final queenStk = stickers.firstWhere(
          (s) => s.id == 'STK_CARROM_01',
          orElse: () => stickers.first,
        );
        widget.mpService.triggerVoiceSticker(
          queenStk,
          isAuto: true,
          reason: 'QUEEN_POCKETED',
        );
      }
    } else if (state.matchComplete) {
      final winStk = stickers.firstWhere(
        (s) => s.id == 'STK_WIN_01',
        orElse: () => stickers.first,
      );
      widget.mpService.triggerVoiceSticker(
        winStk,
        isAuto: true,
        reason: 'MATCH_VICTORY',
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B132B),
      body: SafeArea(
        child: ValueListenableBuilder<MatchStateSnapshot>(
          valueListenable: _game.stateNotifier,
          builder: (context, state, _) {
            return Stack(
              children: [
                Column(
                  children: [
                    _buildTopScoreBar(state),
                    _buildStatusBanner(state),
                    Expanded(
                      child: Center(
                        child: AspectRatio(
                          aspectRatio: 1.0,
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: GameWidget(game: _game),
                          ),
                        ),
                      ),
                    ),
                    _buildFavoriteStickerQuickRow(),
                    if (state.matchComplete)
                      _buildVictoryPanel(state)
                    else
                      _buildStrikerControlDock(state),
                  ],
                ),
                Positioned(
                  top: 108,
                  left: 24,
                  right: 24,
                  child: IgnorePointer(
                    child: ValueListenableBuilder<ActiveStickerAnimationEvent?>(
                      valueListenable: widget.mpService.activeStickerOverlay,
                      builder: (_, activeEv, __) {
                        if (activeEv == null) return const SizedBox.shrink();
                        return TweenAnimationBuilder<double>(
                          tween: Tween(begin: 0.75, end: 1.0),
                          duration: const Duration(milliseconds: 260),
                          curve: Curves.elasticOut,
                          builder: (_, scale, child) =>
                              Transform.scale(scale: scale, child: child),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 10,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFF1C2541).withOpacity(0.95),
                              borderRadius: BorderRadius.circular(18),
                              border: Border.all(
                                color: activeEv.sticker.badgeColor,
                                width: 2,
                              ),
                              boxShadow: const [
                                BoxShadow(color: Colors.black54, blurRadius: 12),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                CircleAvatar(
                                  backgroundColor: activeEv.sticker.badgeColor,
                                  child: Icon(
                                    activeEv.sticker.icon,
                                    color: Colors.black,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Flexible(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        activeEv.isAutoTrigger
                                            ? '${activeEv.senderName} • AUTO (${activeEv.triggerReason})'
                                            : activeEv.senderName,
                                        style: const TextStyle(
                                          color: Color(0xFFFFD700),
                                          fontSize: 11,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      Text(
                                        activeEv.sticker.burmeseText,
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 16,
                                          fontWeight: FontWeight.w900,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                if (_showStickerDrawer)
                  Positioned(
                    bottom: 138,
                    left: 14,
                    right: 14,
                    child: _buildFloatingStickerPicker(),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildFavoriteStickerQuickRow() {
    return Container(
      height: 42,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      color: const Color(0xFF141E30),
      child: Row(
        children: [
          IconButton(
            tooltip: 'Open All 35+ Voice Stickers',
            icon: Icon(
              _showStickerDrawer ? Icons.close : Icons.record_voice_over,
              color: const Color(0xFFFFD700),
              size: 20,
            ),
            onPressed: () =>
                setState(() => _showStickerDrawer = !_showStickerDrawer),
          ),
          IconButton(
            tooltip: 'Quick Chat',
            icon: const Icon(Icons.chat_bubble_outline, color: Color(0xFF00B4D8), size: 19),
            onPressed: () {
              showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                backgroundColor: Colors.transparent,
                builder: (_) => MyanmarChatSheet(mpService: widget.mpService),
              );
            },
          ),
          Expanded(
            child: ValueListenableBuilder<List<String>>(
              valueListenable: widget.mpService.favoriteStickerIds,
              builder: (_, favIds, __) {
                final all = widget.mpService.voiceStickers.value;
                final favModels = all.where((s) => favIds.contains(s.id)).toList();
                return ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: favModels.length,
                  itemBuilder: (_, i) {
                    final stk = favModels[i];
                    return Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 5),
                      child: InkWell(
                        borderRadius: BorderRadius.circular(14),
                        onTap: () => widget.mpService.triggerVoiceSticker(stk),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                          decoration: BoxDecoration(
                            color: const Color(0xFF1C2541),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: stk.badgeColor.withOpacity(0.8)),
                          ),
                          child: Row(
                            children: [
                              Icon(stk.icon, color: stk.badgeColor, size: 14),
                              const SizedBox(width: 4),
                              Text(
                                stk.burmeseText,
                                style: const TextStyle(color: Colors.white, fontSize: 11),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          ValueListenableBuilder<PlayerVoiceSettingsModel>(
            valueListenable: widget.mpService.voiceSettings,
            builder: (_, settings, __) {
              return IconButton(
                tooltip: 'Mute Opponent Voice',
                icon: Icon(
                  settings.opponentVoiceEnabled ? Icons.volume_up : Icons.volume_off,
                  color: settings.opponentVoiceEnabled ? Colors.greenAccent : Colors.redAccent,
                  size: 20,
                ),
                onPressed: () {
                  settings.opponentVoiceEnabled = !settings.opponentVoiceEnabled;
                  widget.mpService.saveVoiceSettings(settings);
                  setState(() {});
                },
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildFloatingStickerPicker() {
    final all = widget.mpService.voiceStickers.value;
    final owned = widget.mpService.ownedStickerIds.value;

    return Container(
      height: 190,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFF1C2541).withOpacity(0.96),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFFFD700), width: 1.5),
      ),
      child: GridView.builder(
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          mainAxisSpacing: 6,
          crossAxisSpacing: 6,
          childAspectRatio: 2.6,
        ),
        itemCount: all.length,
        itemBuilder: (_, i) {
          final stk = all[i];
          final isUnlocked = owned.contains(stk.id) || stk.isFreeDefault;
          return InkWell(
            onTap: () {
              if (!isUnlocked) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Shop တွင် ဤ Voice Pack ကို အရင်ဝယ်ယူပါ')),
                );
                return;
              }
              widget.mpService.triggerVoiceSticker(stk);
              setState(() => _showStickerDrawer = false);
            },
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 6),
              decoration: BoxDecoration(
                color: isUnlocked ? const Color(0xFF0B132B) : Colors.black38,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: isUnlocked ? stk.badgeColor : Colors.white24,
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    isUnlocked ? stk.icon : Icons.lock,
                    color: isUnlocked ? stk.badgeColor : Colors.white38,
                    size: 15,
                  ),
                  const SizedBox(width: 4),
                  Expanded(
                    child: Text(
                      stk.burmeseText,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: isUnlocked ? Colors.white : Colors.white38,
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildTopScoreBar(MatchStateSnapshot state) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: const BoxDecoration(
        color: Color(0xFF1C2541),
        border: Border(
          bottom: BorderSide(color: Color(0xFFD4AF37), width: 1.5),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          _buildTeamScoreCard(
            title: 'အဖြူအသင်း (White)',
            score: state.whiteTeamScore,
            coinsLeft: state.remainingWhiteCoins,
            isTurn: state.activePlayer.assignedColor == CoinType.white,
          ),
          Column(
            children: [
              Text(
                'BOARD ${state.currentBoardNumber}/${widget.config.maxBoards}',
                style: const TextStyle(
                  color: Color(0xFFD4AF37),
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 4),
              _buildQueenBadge(state.queenStatus),
            ],
          ),
          _buildTeamScoreCard(
            title: 'အမည်းအသင်း (Black)',
            score: state.blackTeamScore,
            coinsLeft: state.remainingBlackCoins,
            isTurn: state.activePlayer.assignedColor == CoinType.black,
          ),
        ],
      ),
    );
  }

  Widget _buildTeamScoreCard({
    required String title,
    required int score,
    required int coinsLeft,
    required bool isTurn,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: isTurn ? const Color(0xFF3A506B) : const Color(0xFF0B132B),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: isTurn ? const Color(0xFFFFD700) : Colors.white24,
          width: isTurn ? 2.0 : 1.0,
        ),
      ),
      child: Column(
        children: [
          Text(title, style: const TextStyle(color: Colors.white70, fontSize: 11)),
          const SizedBox(height: 2),
          Text(
            '$score မှတ်',
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
          Text(
            'ကျန်ဇယ်: $coinsLeft',
            style: const TextStyle(color: Color(0xFFD4AF37), fontSize: 11),
          ),
        ],
      ),
    );
  }

  Widget _buildQueenBadge(QueenStatus status) {
    String label;
    Color badgeColor;
    switch (status) {
      case QueenStatus.onBoard:
        label = 'ဘုရင်မ: စားပွဲပေါ်ရှိ';
        badgeColor = const Color(0xFFC62828);
        break;
      case QueenStatus.pocketedPendingCover:
        label = 'ဘုရင်မ: Cover လိုအပ်!';
        badgeColor = const Color(0xFFFF8F00);
        break;
      case QueenStatus.coveredByWhite:
        label = 'ဘုရင်မ: အဖြူ Cover';
        badgeColor = const Color(0xFF2E7D32);
        break;
      case QueenStatus.coveredByBlack:
        label = 'ဘုရင်မ: အမည်း Cover';
        badgeColor = const Color(0xFF2E7D32);
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: badgeColor,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        label,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 11,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Widget _buildStatusBanner(MatchStateSnapshot state) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      color: const Color(0xFF141E30),
      child: Column(
        children: [
          Text(
            'အလှည့်ကျသူ: ${state.activePlayer.name}',
            style: const TextStyle(
              color: Color(0xFFFFD700),
              fontWeight: FontWeight.bold,
              fontSize: 13,
            ),
          ),
          Text(
            state.bannerMessage,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white70, fontSize: 11),
          ),
        ],
      ),
    );
  }

  Widget _buildStrikerControlDock(MatchStateSnapshot state) {
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 6, 18, 12),
      decoration: const BoxDecoration(
        color: Color(0xFF1C2541),
        border: Border(top: BorderSide(color: Color(0xFFD4AF37), width: 1.5)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Striker နေရာရွှေ့ရန် (Baseline Slider)',
                style: TextStyle(color: Colors.white, fontSize: 12),
              ),
              TextButton.icon(
                onPressed: () => Navigator.of(context).pop(),
                icon: const Icon(Icons.exit_to_app, color: Colors.white70, size: 15),
                label: const Text('Lobby', style: TextStyle(color: Colors.white70, fontSize: 12)),
              ),
            ],
          ),
          Slider(
            value: _sliderValue,
            min: -1.0,
            max: 1.0,
            activeColor: const Color(0xFFD4AF37),
            thumbColor: const Color(0xFF00B4D8),
            onChanged: state.isStrikerMoving
                ? null
                : (val) {
                    setState(() => _sliderValue = val);
                    _game.updateStrikerBaselineSlider(val);
                  },
          ),
        ],
      ),
    );
  }

  Widget _buildVictoryPanel(MatchStateSnapshot state) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      color: const Color(0xFF1C2541),
      child: Column(
        children: [
          Text(
            state.winnerAnnouncement ?? 'ပွဲစဉ် ပြီးဆုံးပါပြီ!',
            style: const TextStyle(
              color: Color(0xFFFFD700),
              fontSize: 17,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFD4AF37),
              foregroundColor: Colors.black,
            ),
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('ပင်မစာမျက်နှာသို့ ပြန်သွားမည်'),
          ),
        ],
      ),
    );
  }
}
