import 'dart:async';
import 'package:flutter/material.dart';
import '../models/game_models.dart';
import '../network/multiplayer_service.dart';
import 'match_hud_overlay.dart';
import 'phase3_social_and_voice_sheets.dart';

class HomeLobbyScreen extends StatefulWidget {
  const HomeLobbyScreen({super.key});

  @override
  State<HomeLobbyScreen> createState() => _HomeLobbyScreenState();
}

class _HomeLobbyScreenState extends State<HomeLobbyScreen> {
  final MultiplayerService _mpService = MultiplayerService();
  final TextEditingController _roomCodeController = TextEditingController();
  StreamSubscription<Map<String, dynamic>>? _sub;

  @override
  void initState() {
    super.initState();
    _mpService.connect();
    _sub = _mpService.events.listen((msg) {
      if (msg['type'] == 'MATCH_STARTED') {
        final snap = msg['snapshot'] as Map<String, dynamic>;
        final modeStr = snap['mode'] as String? ?? 'DUEL_1V1';
        final mode =
            modeStr == 'TEAM_2V2' ? BattleMode.team2v2 : BattleMode.duel1v1;
        if (!mounted) return;
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => MatchScreen(
              config: MatchConfig(mode: mode, targetPoints: 25, maxBoards: 8),
              mpService: _mpService,
              initialServerSnapshot: snap,
              isOnline: true,
            ),
          ),
        );
      } else if (msg['type'] == 'MATCH_INVITE_RECEIVED' && mounted) {
        final fromName = msg['fromDisplayName'] ?? 'Friend';
        final code = msg['roomCode'] as String? ?? '';
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$fromName က စိန်ခေါ်ထားပါသည် (Room: $code)'),
            action: SnackBarAction(
              label: 'JOIN NOW',
              onPressed: () => _mpService.joinPrivateRoom(code),
            ),
          ),
        );
      }
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    _roomCodeController.dispose();
    _mpService.dispose();
    super.dispose();
  }

  void _openSheet(Widget sheet) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => sheet,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0B132B),
      body: SafeArea(
        child: Column(
          children: [
            _buildTopHeaderBar(),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Center(
                      child: Text(
                        'MYANMAR CARROM LEGENDS',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color(0xFFFFD700),
                          fontSize: 23,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 1.3,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    _buildOnlineMatchmakingCard(),
                    const SizedBox(height: 16),
                    const Text(
                      'LOCAL PLAY / TRAINING (WITH 35+ MYANMAR VOICE STICKERS)',
                      style: TextStyle(
                        color: Color(0xFFD4AF37),
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                    const SizedBox(height: 10),
                    _buildBattleModeCard(
                      context: context,
                      title: 'LOCAL DUEL BATTLE (1 vs 1)',
                      subtitle: 'ဖုန်းတစ်လုံးတည်းတွင် ၂ ဦး အလှည့်ကျ ကစားရန်',
                      icon: Icons.person_pin_circle_rounded,
                      accentColor: const Color(0xFF00B4D8),
                      mode: BattleMode.duel1v1,
                    ),
                    const SizedBox(height: 10),
                    _buildBattleModeCard(
                      context: context,
                      title: 'LOCAL TEAM BATTLE (2 vs 2 DOUBLES)',
                      subtitle: 'ကစားသမား ၄ ဦး အသင်းလိုက် (မျက်နှာချင်းဆိုင်)',
                      icon: Icons.groups_rounded,
                      accentColor: const Color(0xFFFFB703),
                      mode: BattleMode.team2v2,
                    ),
                  ],
                ),
              ),
            ),
            _buildPhase3NavigationDock(),
          ],
        ),
      ),
    );
  }

  Widget _buildTopHeaderBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: const BoxDecoration(
        color: Color(0xFF1C2541),
        border: Border(bottom: BorderSide(color: Color(0xFFD4AF37), width: 1.5)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              const CircleAvatar(
                radius: 18,
                backgroundColor: Color(0xFFD4AF37),
                child: Icon(Icons.emoji_events, color: Color(0xFF0B132B)),
              ),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _mpService.displayName,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                    ),
                  ),
                  ValueListenableBuilder<bool>(
                    valueListenable: _mpService.isConnected,
                    builder: (_, connected, __) => Text(
                      connected ? '● ONLINE SERVER READY' : '○ LOCAL + 35 VOICE STICKERS',
                      style: TextStyle(
                        color: connected ? Colors.greenAccent : Colors.amber,
                        fontSize: 10,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
          Row(
            children: [
              ValueListenableBuilder<int>(
                valueListenable: _mpService.goldBalance,
                builder: (_, gold, __) => Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: const Color(0xFF0B132B),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: const Color(0xFFD4AF37)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.monetization_on, color: Color(0xFFFFD700), size: 15),
                      const SizedBox(width: 4),
                      Text(
                        '$gold',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              IconButton(
                tooltip: 'Voice Settings',
                onPressed: () =>
                    _openSheet(VoiceSettingsSheet(mpService: _mpService)),
                icon: const Icon(Icons.tune, color: Color(0xFFFFD700)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildOnlineMatchmakingCard() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFF1C2541),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFFFD700), width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'ONLINE REAL-TIME MULTIPLAYER (PHASE 2 & 3)',
            style: TextStyle(
              color: Color(0xFFFFD700),
              fontWeight: FontWeight.bold,
              fontSize: 13,
            ),
          ),
          const SizedBox(height: 4),
          ValueListenableBuilder<String>(
            valueListenable: _mpService.statusMessage,
            builder: (_, status, __) => Text(
              status,
              style: const TextStyle(color: Colors.white70, fontSize: 11),
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF00B4D8),
                    foregroundColor: Colors.black,
                  ),
                  onPressed: () => _mpService.queueMatchmaking(isTeam2v2: false),
                  icon: const Icon(Icons.flash_on, size: 18),
                  label: const Text('1v1 Online'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFFFB703),
                    foregroundColor: Colors.black,
                  ),
                  onPressed: () => _mpService.queueMatchmaking(isTeam2v2: true),
                  icon: const Icon(Icons.groups, size: 18),
                  label: const Text('2v2 Online'),
                ),
              ),
            ],
          ),
          const Divider(color: Colors.white24, height: 18),
          Row(
            children: [
              OutlinedButton(
                style: OutlinedButton.styleFrom(
                  foregroundColor: const Color(0xFFFFD700),
                  side: const BorderSide(color: Color(0xFFFFD700)),
                ),
                onPressed: () => _mpService.createPrivateRoom(isTeam2v2: false),
                child: const Text('Create Room'),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: _roomCodeController,
                  textCapitalization: TextCapitalization.characters,
                  decoration: const InputDecoration(
                    hintText: 'Room Code',
                    isDense: true,
                    contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFD4AF37),
                  foregroundColor: Colors.black,
                ),
                onPressed: () =>
                    _mpService.joinPrivateRoom(_roomCodeController.text),
                child: const Text('Join'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBattleModeCard({
    required BuildContext context,
    required String title,
    required String subtitle,
    required IconData icon,
    required Color accentColor,
    required BattleMode mode,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => MatchScreen(
              config: MatchConfig(mode: mode, targetPoints: 25, maxBoards: 8),
              mpService: _mpService,
              isOnline: false,
            ),
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: const Color(0xFF1C2541),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white24),
        ),
        child: Row(
          children: [
            Icon(icon, color: accentColor, size: 30),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    style: const TextStyle(color: Colors.white70, fontSize: 11),
                  ),
                ],
              ),
            ),
            const Icon(Icons.play_arrow_rounded, color: Color(0xFFFFD700), size: 28),
          ],
        ),
      ),
    );
  }

  Widget _buildPhase3NavigationDock() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      decoration: const BoxDecoration(
        color: Color(0xFF1C2541),
        border: Border(top: BorderSide(color: Color(0xFFD4AF37), width: 1.2)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildDockButton(
            icon: Icons.record_voice_over,
            label: 'Voice Shop (35+)',
            onTap: () =>
                _openSheet(VoiceShopAndInventorySheet(mpService: _mpService)),
          ),
          _buildDockButton(
            icon: Icons.people_alt_rounded,
            label: 'Friends',
            onTap: () =>
                _openSheet(FriendsAndSocialSheet(mpService: _mpService)),
          ),
          _buildDockButton(
            icon: Icons.forum_rounded,
            label: 'MM Chat',
            onTap: () => _openSheet(MyanmarChatSheet(mpService: _mpService)),
          ),
          _buildDockButton(
            icon: Icons.settings_voice,
            label: 'Voice Config',
            onTap: () => _openSheet(VoiceSettingsSheet(mpService: _mpService)),
          ),
          _buildDockButton(
            icon: Icons.admin_panel_settings,
            label: 'Admin OTA',
            onTap: () =>
                _openSheet(AdminVoiceManagementSheet(mpService: _mpService)),
          ),
        ],
      ),
    );
  }

  Widget _buildDockButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: const Color(0xFFFFD700), size: 22),
          const SizedBox(height: 3),
          Text(
            label,
            style: const TextStyle(color: Colors.white, fontSize: 10),
          ),
        ],
      ),
    );
  }
}
