import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../models/phase3_models.dart';
import '../network/multiplayer_service.dart';
import '../services/voice_audio_engine.dart';

class VoiceShopAndInventorySheet extends StatefulWidget {
  final MultiplayerService mpService;

  const VoiceShopAndInventorySheet({super.key, required this.mpService});

  @override
  State<VoiceShopAndInventorySheet> createState() =>
      _VoiceShopAndInventorySheetState();
}

class _VoiceShopAndInventorySheetState extends State<VoiceShopAndInventorySheet>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String _selectedCategory = 'ALL';

  static const Map<String, String> categoryLabels = {
    'ALL': 'အားလုံး (35+)',
    'CAT_LAUGH': 'ရယ်မောသံ',
    'CAT_TEASE': 'စနောက်သံ',
    'CAT_WIN': 'အောင်ပွဲခံ',
    'CAT_LOSE': 'ရှုံးနိမ့်သံ',
    'CAT_CHALLENGE': 'စိန်ခေါ်သံ',
    'CAT_CARROM': 'ဇယ်ခုံအထူး',
    'CAT_REACTION': 'တုံ့ပြန်သံ',
  };

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.84,
      decoration: const BoxDecoration(
        color: Color(0xFF0B132B),
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'မြန်မာ အသံစတစ်ကာ ဆိုင်နှင့် Inventory',
                  style: TextStyle(
                    color: Color(0xFFFFD700),
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                ValueListenableBuilder<int>(
                  valueListenable: widget.mpService.goldBalance,
                  builder: (_, gold, __) => Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                    decoration: BoxDecoration(
                      color: const Color(0xFF1C2541),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: const Color(0xFFFFD700)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.monetization_on, color: Color(0xFFFFD700), size: 16),
                        const SizedBox(width: 5),
                        Text(
                          '$gold GOLD',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          TabBar(
            controller: _tabController,
            indicatorColor: const Color(0xFFFFD700),
            labelColor: const Color(0xFFFFD700),
            unselectedLabelColor: Colors.white60,
            tabs: const [
              Tab(text: 'VOICE PACK SHOP (၅ ထုပ်)'),
              Tab(text: 'စတစ်ကာ ၃၅+ နှင့် FAVORITES'),
            ],
          ),
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                _buildVoicePackShopTab(),
                _buildStickerInventoryTab(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVoicePackShopTab() {
    return ValueListenableBuilder<List<VoicePackModel>>(
      valueListenable: widget.mpService.voicePacks,
      builder: (_, packs, __) {
        return ValueListenableBuilder<Set<String>>(
          valueListenable: widget.mpService.ownedPackIds,
          builder: (_, ownedPacks, __) {
            return ListView.builder(
              padding: const EdgeInsets.all(14),
              itemCount: packs.length,
              itemBuilder: (ctx, i) {
                final pack = packs[i];
                final isOwned = ownedPacks.contains(pack.id) || pack.isFree;
                final packStickers = widget.mpService.voiceStickers.value
                    .where((s) => s.packId == pack.id)
                    .toList();

                return Container(
                  margin: const EdgeInsets.only(bottom: 14),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: const Color(0xFF1C2541),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: isOwned ? const Color(0xFF00E676) : const Color(0xFFD4AF37),
                      width: 1.4,
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              pack.nameMm,
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 15,
                              ),
                            ),
                          ),
                          if (pack.isLimitedTime)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: const Color(0xFFFF2A85),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Text(
                                'LIMITED EVENT',
                                style: TextStyle(color: Colors.white, fontSize: 10),
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        pack.descriptionMm,
                        style: const TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: packStickers.map((stk) {
                          return InkWell(
                            onTap: () {
                              VoiceAudioEngine.instance.playStickerAudio(
                                sticker: stk,
                                settings: widget.mpService.voiceSettings.value,
                                senderId: widget.mpService.userId,
                                myUserId: widget.mpService.userId,
                              );
                            },
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: const Color(0xFF0B132B),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: Colors.white24),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.volume_up, color: Color(0xFFFFD700), size: 14),
                                  const SizedBox(width: 4),
                                  Text(
                                    stk.burmeseText,
                                    style: const TextStyle(color: Colors.white, fontSize: 11),
                                  ),
                                ],
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          if (isOwned)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                              decoration: BoxDecoration(
                                color: const Color(0xFF00E676).withOpacity(0.2),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: const Text(
                                '✓ ပိုင်ဆိုင်ပြီး (OWNED)',
                                style: TextStyle(
                                  color: Color(0xFF00E676),
                                  fontWeight: FontWeight.bold,
                                  fontSize: 12,
                                ),
                              ),
                            )
                          else
                            ElevatedButton.icon(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFFFFD700),
                                foregroundColor: Colors.black,
                              ),
                              onPressed: () {
                                widget.mpService.purchasePack(pack.id);
                                setState(() {});
                              },
                              icon: const Icon(Icons.shopping_cart_checkout, size: 16),
                              label: Text('Unlock (${pack.goldPrice} Gold)'),
                            ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            );
          },
        );
      },
    );
  }

  Widget _buildStickerInventoryTab() {
    return Column(
      children: [
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          child: Row(
            children: categoryLabels.entries.map((entry) {
              final active = _selectedCategory == entry.key;
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(entry.value, style: const TextStyle(fontSize: 11)),
                  selected: active,
                  selectedColor: const Color(0xFFFFD700),
                  labelStyle: TextStyle(
                    color: active ? Colors.black : Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                  onSelected: (_) => setState(() => _selectedCategory = entry.key),
                ),
              );
            }).toList(),
          ),
        ),
        Expanded(
          child: ValueListenableBuilder<List<VoiceStickerModel>>(
            valueListenable: widget.mpService.voiceStickers,
            builder: (_, allStickers, __) {
              final filtered = _selectedCategory == 'ALL'
                  ? allStickers
                  : allStickers.where((s) => s.categoryId == _selectedCategory).toList();

              return ValueListenableBuilder<Set<String>>(
                valueListenable: widget.mpService.ownedStickerIds,
                builder: (_, ownedIds, __) {
                  return ValueListenableBuilder<List<String>>(
                    valueListenable: widget.mpService.favoriteStickerIds,
                    builder: (_, favIds, __) {
                      return ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 14),
                        itemCount: filtered.length,
                        itemBuilder: (ctx, i) {
                          final stk = filtered[i];
                          final unlocked = ownedIds.contains(stk.id) || stk.isFreeDefault;
                          final isFav = favIds.contains(stk.id);

                          return Card(
                            color: const Color(0xFF1C2541),
                            margin: const EdgeInsets.only(bottom: 8),
                            child: ListTile(
                              leading: CircleAvatar(
                                backgroundColor: stk.badgeColor.withOpacity(0.2),
                                child: Icon(stk.icon, color: stk.badgeColor),
                              ),
                              title: Text(
                                stk.burmeseText,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 14,
                                ),
                              ),
                              subtitle: Text(
                                unlocked ? 'Unlocked • အသံစမ်းနားထောင်ရန် နှိပ်ပါ' : 'Locked (${stk.packId})',
                                style: TextStyle(
                                  color: unlocked ? Colors.greenAccent : Colors.amber,
                                  fontSize: 11,
                                ),
                              ),
                              trailing: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  IconButton(
                                    tooltip: 'Preview Myanmar Audio',
                                    icon: const Icon(Icons.play_circle_fill, color: Color(0xFF00B4D8)),
                                    onPressed: () {
                                      VoiceAudioEngine.instance.playStickerAudio(
                                        sticker: stk,
                                        settings: widget.mpService.voiceSettings.value,
                                        senderId: widget.mpService.userId,
                                        myUserId: widget.mpService.userId,
                                      );
                                    },
                                  ),
                                  if (unlocked)
                                    IconButton(
                                      tooltip: 'Pin to Match Quick Bar',
                                      icon: Icon(
                                        isFav ? Icons.star_rounded : Icons.star_border_rounded,
                                        color: const Color(0xFFFFD700),
                                      ),
                                      onPressed: () {
                                        widget.mpService.toggleFavoriteSticker(stk.id);
                                      },
                                    ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    },
                  );
                },
              );
            },
          ),
        ),
      ],
    );
  }
}

class VoiceSettingsSheet extends StatefulWidget {
  final MultiplayerService mpService;

  const VoiceSettingsSheet({super.key, required this.mpService});

  @override
  State<VoiceSettingsSheet> createState() => _VoiceSettingsSheetState();
}

class _VoiceSettingsSheetState extends State<VoiceSettingsSheet> {
  late PlayerVoiceSettingsModel _draft;

  @override
  void initState() {
    super.initState();
    final cur = widget.mpService.voiceSettings.value;
    _draft = PlayerVoiceSettingsModel.fromJson(cur.toJson());
  }

  void _save() {
    widget.mpService.saveVoiceSettings(_draft);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Voice Settings သိမ်းဆည်းပြီးပါပြီ')),
    );
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(
        color: Color(0xFF0B132B),
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'PERSONAL VOICE & AUDIO SETTINGS',
              style: TextStyle(
                color: Color(0xFFFFD700),
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 14),
            _buildSliderRow(
              'Master Sound Volume',
              _draft.masterVolume,
              (v) => setState(() => _draft.masterVolume = v),
            ),
            _buildSliderRow(
              'Myanmar Voice Sticker Volume',
              _draft.voiceStickerVolume,
              (v) => setState(() => _draft.voiceStickerVolume = v),
            ),
            _buildSliderRow(
              'Carrom Physics SFX Volume',
              _draft.sfxVolume,
              (v) => setState(() => _draft.sfxVolume = v),
            ),
            const Divider(color: Colors.white24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('ကျွန်ုပ်၏ အသံအမျိုးအစား:', style: TextStyle(color: Colors.white)),
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'MALE', label: Text('ကျား (Male)')),
                    ButtonSegment(value: 'FEMALE', label: Text('မ (Female)')),
                  ],
                  selected: {_draft.preferredGender},
                  onSelectionChanged: (s) => setState(() => _draft.preferredGender = s.first),
                ),
              ],
            ),
            SwitchListTile(
              title: const Text('Auto Voice Trigger (အလိုအလျောက် အသံထွက်စနစ်)'),
              subtitle: const Text('Queen ဝင်ချိန်နှင့် ပွဲနိုင်ချိန် အလိုအလျောက် အောင်ပွဲခံမည်'),
              value: _draft.autoVoiceEnabled,
              activeColor: const Color(0xFFFFD700),
              onChanged: (v) => setState(() => _draft.autoVoiceEnabled = v),
            ),
            SwitchListTile(
              title: const Text('Opponent Voice On/Off (ပြိုင်ဘက်အသံ ဖွင့်/ပိတ်)'),
              value: _draft.opponentVoiceEnabled,
              activeColor: const Color(0xFFFFD700),
              onChanged: (v) => setState(() => _draft.opponentVoiceEnabled = v),
            ),
            SwitchListTile(
              title: const Text('Auto Tease on Opponent Foul/Miss'),
              value: _draft.allowAutoTease,
              activeColor: const Color(0xFFFFD700),
              onChanged: (v) => setState(() => _draft.allowAutoTease = v),
            ),
            SwitchListTile(
              title: const Text('Mute All Voices (အသံအားလုံး ပိတ်ထားမည်)'),
              value: _draft.muteAll,
              activeColor: Colors.redAccent,
              onChanged: (v) => setState(() => _draft.muteAll = v),
            ),
            const SizedBox(height: 6),
            Text(
              'Voice Sticker Cooldown: ${_draft.cooldownSeconds} စက္ကန့်',
              style: const TextStyle(color: Colors.white70, fontSize: 12),
            ),
            Slider(
              value: _draft.cooldownSeconds.toDouble(),
              min: 3,
              max: 20,
              divisions: 17,
              activeColor: const Color(0xFF00B4D8),
              onChanged: (v) => setState(() => _draft.cooldownSeconds = v.round()),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFFD700),
                  foregroundColor: Colors.black,
                ),
                onPressed: _save,
                child: const Text('SAVE PREFERENCES'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSliderRow(String label, double value, ValueChanged<double> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('$label (${(value * 100).round()}%)', style: const TextStyle(color: Colors.white70, fontSize: 12)),
        Slider(
          value: value,
          min: 0.0,
          max: 1.0,
          activeColor: const Color(0xFFFFD700),
          onChanged: onChanged,
        ),
      ],
    );
  }
}

class FriendsAndSocialSheet extends StatefulWidget {
  final MultiplayerService mpService;

  const FriendsAndSocialSheet({super.key, required this.mpService});

  @override
  State<FriendsAndSocialSheet> createState() => _FriendsAndSocialSheetState();
}

class _FriendsAndSocialSheetState extends State<FriendsAndSocialSheet> {
  final TextEditingController _searchCtrl = TextEditingController();
  List<Map<String, dynamic>> _searchResults = [];

  @override
  void initState() {
    super.initState();
    widget.mpService.events.listen((msg) {
      if (msg['type'] == 'PLAYER_SEARCH_RESULTS' && mounted) {
        setState(() {
          _searchResults = (msg['results'] as List<dynamic>)
              .map((e) => e as Map<String, dynamic>)
              .toList();
        });
      }
    });
    widget.mpService.send('SEARCH_PLAYERS', {'query': ''});
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.78,
      padding: const EdgeInsets.all(18),
      decoration: const BoxDecoration(
        color: Color(0xFF0B132B),
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'သူငယ်ချင်းများ နှင့် စိန်ခေါ်မှုစနစ် (FRIENDS & CHALLENGE)',
            style: TextStyle(
              color: Color(0xFFFFD700),
              fontSize: 15,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _searchCtrl,
                  decoration: const InputDecoration(
                    hintText: 'ကစားသမားအမည် ရှာဖွေရန်...',
                    isDense: true,
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: () => widget.mpService.send('SEARCH_PLAYERS', {'query': _searchCtrl.text}),
                child: const Text('ရှာမည်'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          const Text('ONLINE PLAYERS:', style: TextStyle(color: Color(0xFF00B4D8), fontSize: 12)),
          SizedBox(
            height: 130,
            child: _searchResults.isEmpty
                ? const Center(
                    child: Text('အခြား Online ကစားသမား မရှိသေးပါ', style: TextStyle(color: Colors.white54)),
                  )
                : ListView.builder(
                    itemCount: _searchResults.length,
                    itemBuilder: (_, i) {
                      final p = _searchResults[i];
                      return ListTile(
                        dense: true,
                        leading: const Icon(Icons.person, color: Colors.greenAccent),
                        title: Text(p['displayName'].toString(), style: const TextStyle(color: Colors.white)),
                        trailing: ElevatedButton(
                          onPressed: () {
                            widget.mpService.send('SEND_FRIEND_REQUEST', {'targetUserId': p['userId']});
                          },
                          child: const Text('Add Friend'),
                        ),
                      );
                    },
                  ),
          ),
          const Divider(color: Colors.white24),
          const Text('MY FRIENDS LIST:', style: TextStyle(color: Color(0xFFFFD700), fontSize: 12)),
          Expanded(
            child: ValueListenableBuilder<List<FriendItemModel>>(
              valueListenable: widget.mpService.friendsList,
              builder: (_, friends, __) {
                if (friends.isEmpty) {
                  return const Center(
                    child: Text('သူငယ်ချင်း စာရင်း မရှိသေးပါ', style: TextStyle(color: Colors.white54)),
                  );
                }
                return ListView.builder(
                  itemCount: friends.length,
                  itemBuilder: (_, i) {
                    final f = friends[i];
                    return ListTile(
                      leading: CircleAvatar(
                        backgroundColor: f.isOnline ? Colors.green : Colors.grey,
                        radius: 7,
                      ),
                      title: Text(f.displayName, style: const TextStyle(color: Colors.white)),
                      subtitle: Text(f.status, style: const TextStyle(color: Colors.white60, fontSize: 11)),
                      trailing: f.status == 'PENDING_RECEIVED'
                          ? Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                IconButton(
                                  icon: const Icon(Icons.check_circle, color: Colors.greenAccent),
                                  onPressed: () => widget.mpService.send('RESPOND_FRIEND_REQUEST', {
                                    'requesterId': f.userId,
                                    'accept': true,
                                  }),
                                ),
                                IconButton(
                                  icon: const Icon(Icons.cancel, color: Colors.redAccent),
                                  onPressed: () => widget.mpService.send('RESPOND_FRIEND_REQUEST', {
                                    'requesterId': f.userId,
                                    'accept': false,
                                  }),
                                ),
                              ],
                            )
                          : ElevatedButton.icon(
                              onPressed: () {
                                widget.mpService.send('INVITE_FRIEND_TO_MATCH', {
                                  'friendUserId': f.userId,
                                });
                                Navigator.of(context).pop();
                              },
                              icon: const Icon(Icons.sports_esports, size: 15),
                              label: const Text('Challenge'),
                            ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class MyanmarChatSheet extends StatefulWidget {
  final MultiplayerService mpService;

  const MyanmarChatSheet({super.key, required this.mpService});

  @override
  State<MyanmarChatSheet> createState() => _MyanmarChatSheetState();
}

class _MyanmarChatSheetState extends State<MyanmarChatSheet> {
  final TextEditingController _msgCtrl = TextEditingController();

  static const List<String> quickMessages = [
    'ကစားကြမယ်။',
    'အဆင်သင့်ပဲလား။',
    'ကောင်းတယ်။',
    'နောက်တစ်ပွဲဆော့မယ်။',
    'ကျေးဇူးပါ။',
    'GG။',
  ];

  void _sendText(String text, {String type = 'TEXT'}) {
    if (text.trim().isEmpty) return;
    widget.mpService.sendChatMessage(text.trim(), msgType: type);
    _msgCtrl.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.72,
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        color: Color(0xFF0B132B),
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'REAL-TIME MYANMAR CHAT & QUICK MESSAGES',
            style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: quickMessages.map((q) {
              return ActionChip(
                backgroundColor: const Color(0xFF1C2541),
                label: Text(q, style: const TextStyle(color: Color(0xFFFFD700), fontSize: 12)),
                onPressed: () => _sendText(q, type: 'QUICK_CHAT'),
              );
            }).toList(),
          ),
          const Divider(color: Colors.white24),
          Expanded(
            child: ValueListenableBuilder<List<ChatMessageModel>>(
              valueListenable: widget.mpService.chatMessages,
              builder: (_, messages, __) {
                if (messages.isEmpty) {
                  return const Center(
                    child: Text('မက်ဆေ့ချ် မရှိသေးပါ — Quick Chat ဖြင့် စတင်နှုတ်ဆက်ပါ', style: TextStyle(color: Colors.white54)),
                  );
                }
                return ListView.builder(
                  itemCount: messages.length,
                  itemBuilder: (_, i) {
                    final m = messages[i];
                    final isMe = m.senderId == widget.mpService.userId;
                    return Align(
                      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: isMe ? const Color(0xFF00B4D8) : const Color(0xFF1C2541),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${m.senderName} • ✓✓',
                              style: TextStyle(
                                color: isMe ? Colors.black87 : const Color(0xFFFFD700),
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Text(
                              m.content,
                              style: TextStyle(
                                color: isMe ? Colors.black : Colors.white,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _msgCtrl,
                  decoration: const InputDecoration(
                    hintText: 'မြန်မာဘာသာဖြင့် စာရိုက်ပါ...',
                    isDense: true,
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton(
                icon: const Icon(Icons.send, color: Color(0xFFFFD700)),
                onPressed: () => _sendText(_msgCtrl.text),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class AdminVoiceManagementSheet extends StatefulWidget {
  final MultiplayerService mpService;

  const AdminVoiceManagementSheet({super.key, required this.mpService});

  @override
  State<AdminVoiceManagementSheet> createState() =>
      _AdminVoiceManagementSheetState();
}

class _AdminVoiceManagementSheetState extends State<AdminVoiceManagementSheet> {
  final TextEditingController _textMmCtrl = TextEditingController();
  final TextEditingController _priceCtrl = TextEditingController(text: '450');
  String _category = 'CAT_LAUGH';
  String _packId = 'PACK_FUNNY';
  final String _anim = 'LAUGH_BOUNCE';

  Future<void> _publishNewStickerOTA() async {
    final text = _textMmCtrl.text.trim();
    if (text.isEmpty) return;

    final newStickerJson = {
      'id': 'STK_OTA_${DateTime.now().millisecondsSinceEpoch}',
      'categoryId': _category,
      'packId': _packId,
      'burmeseText': text,
      'phoneticText': text,
      'cdnAudioMale': '/cdn/audio/male/custom_ota.ogg',
      'cdnAudioFemale': '/cdn/audio/female/custom_ota.ogg',
      'animationType': _anim,
      'autoTrigger': 'MANUAL_ONLY',
      'goldPrice': int.tryParse(_priceCtrl.text) ?? 450,
      'isFreeDefault': _packId == 'PACK_FREE_BASIC',
      'isEnabled': true,
      'pitchMale': 1.05,
      'pitchFemale': 1.32,
      'rate': 0.92,
    };

    try {
      await http
          .post(
            Uri.parse('http://10.0.2.2:8080/api/admin/voice-stickers'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode(newStickerJson),
          )
          .timeout(const Duration(seconds: 2));
    } catch (_) {
      final added = VoiceStickerModel.fromJson(newStickerJson);
      widget.mpService.voiceStickers.value = [
        ...widget.mpService.voiceStickers.value,
        added,
      ];
      if (added.isFreeDefault) {
        widget.mpService.ownedStickerIds.value = {
          ...widget.mpService.ownedStickerIds.value,
          added.id,
        };
      }
    }

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('OTA Sticker "$text" Published without APK Rebuild!')),
    );
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(
        color: Color(0xFF0B132B),
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'ADMIN DASHBOARD: PUBLISH NEW OTA MYANMAR VOICE STICKER',
              style: TextStyle(color: Color(0xFFFFD700), fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 6),
            const Text(
              'APK အသစ် ပြန်ထုတ်စရာမလိုဘဲ စတစ်ကာအသစ်နှင့် အသံဖိုင်များကို တိုက်ရိုက်ထည့်သွင်းနိုင်သည်',
              style: TextStyle(color: Colors.white70, fontSize: 12),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _textMmCtrl,
              decoration: const InputDecoration(
                labelText: 'မြန်မာ စတစ်ကာစာသား (ဥပမာ - ဆရာကြီးပဲဟေ့)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _category,
              decoration: const InputDecoration(labelText: 'Category', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 'CAT_LAUGH', child: Text('Laughing Pack')),
                DropdownMenuItem(value: 'CAT_TEASE', child: Text('Teasing Pack')),
                DropdownMenuItem(value: 'CAT_WIN', child: Text('Winning Pack')),
                DropdownMenuItem(value: 'CAT_LOSE', child: Text('Losing Pack')),
                DropdownMenuItem(value: 'CAT_CHALLENGE', child: Text('Challenge Pack')),
                DropdownMenuItem(value: 'CAT_CARROM', child: Text('Special Carrom Pack')),
                DropdownMenuItem(value: 'CAT_REACTION', child: Text('Reaction Pack')),
              ],
              onChanged: (v) => setState(() => _category = v ?? 'CAT_LAUGH'),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: _packId,
              decoration: const InputDecoration(labelText: 'Voice Pack', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 'PACK_FREE_BASIC', child: Text('Free Basic Pack')),
                DropdownMenuItem(value: 'PACK_FUNNY', child: Text('Funny Pack')),
                DropdownMenuItem(value: 'PACK_PRO', child: Text('Pro Pack')),
                DropdownMenuItem(value: 'PACK_MYANMAR_LEGEND', child: Text('Myanmar Legend Pack')),
                DropdownMenuItem(value: 'PACK_SPECIAL_EVENT', child: Text('Special Event Pack')),
              ],
              onChanged: (v) => setState(() => _packId = v ?? 'PACK_FUNNY'),
            ),
            const SizedBox(height: 14),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF00E676),
                  foregroundColor: Colors.black,
                ),
                onPressed: _publishNewStickerOTA,
                icon: const Icon(Icons.cloud_upload),
                label: const Text('PUBLISH LIVE TO ALL ANDROID PLAYERS'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
