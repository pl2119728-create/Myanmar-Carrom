import 'package:flutter/material.dart';

class VoiceStickerModel {
  final String id;
  final String categoryId;
  final String packId;
  final String burmeseText;
  final String phoneticText;
  final String cdnAudioMale;
  final String cdnAudioFemale;
  final String animationType;
  final String autoTrigger;
  final int goldPrice;
  final bool isFreeDefault;
  final double pitchMale;
  final double pitchFemale;
  final double rate;

  const VoiceStickerModel({
    required this.id,
    required this.categoryId,
    required this.packId,
    required this.burmeseText,
    required this.phoneticText,
    required this.cdnAudioMale,
    required this.cdnAudioFemale,
    required this.animationType,
    required this.autoTrigger,
    required this.goldPrice,
    required this.isFreeDefault,
    required this.pitchMale,
    required this.pitchFemale,
    required this.rate,
  });

  factory VoiceStickerModel.fromJson(Map<String, dynamic> json) {
    return VoiceStickerModel(
      id: json['id'] as String,
      categoryId: json['categoryId'] as String,
      packId: json['packId'] as String,
      burmeseText: json['burmeseText'] as String,
      phoneticText: json['phoneticText'] as String? ?? '',
      cdnAudioMale: json['cdnAudioMale'] as String? ?? '',
      cdnAudioFemale: json['cdnAudioFemale'] as String? ?? '',
      animationType: json['animationType'] as String? ?? 'LAUGH_BOUNCE',
      autoTrigger: json['autoTrigger'] as String? ?? 'MANUAL_ONLY',
      goldPrice: (json['goldPrice'] as num?)?.toInt() ?? 0,
      isFreeDefault: json['isFreeDefault'] as bool? ?? false,
      pitchMale: (json['pitchMale'] as num?)?.toDouble() ?? 1.0,
      pitchFemale: (json['pitchFemale'] as num?)?.toDouble() ?? 1.3,
      rate: (json['rate'] as num?)?.toDouble() ?? 0.92,
    );
  }

  IconData get icon {
    switch (animationType) {
      case 'LAUGH_BOUNCE':
        return Icons.sentiment_very_satisfied_rounded;
      case 'TEASE_WINK':
        return Icons.face_retouching_natural_rounded;
      case 'VICTORY_DANCE':
        return Icons.emoji_events_rounded;
      case 'CRY_DROP':
        return Icons.sentiment_dissatisfied_rounded;
      case 'CHALLENGE_FIRE':
        return Icons.local_fire_department_rounded;
      case 'QUEEN_CROWN':
        return Icons.workspace_premium_rounded;
      default:
        return Icons.bolt_rounded;
    }
  }

  Color get badgeColor {
    switch (categoryId) {
      case 'CAT_LAUGH':
        return const Color(0xFFFFB703);
      case 'CAT_TEASE':
        return const Color(0xFFFF2A85);
      case 'CAT_WIN':
        return const Color(0xFF00E676);
      case 'CAT_LOSE':
        return const Color(0xFF7209B7);
      case 'CAT_CHALLENGE':
        return const Color(0xFFFF5400);
      case 'CAT_CARROM':
        return const Color(0xFFFFD700);
      default:
        return const Color(0xFF00B4D8);
    }
  }
}

class VoicePackModel {
  final String id;
  final String nameMm;
  final String nameEn;
  final String descriptionMm;
  final String tier;
  final int goldPrice;
  final bool isFree;
  final bool isLimitedTime;
  final String bannerColorHex;

  const VoicePackModel({
    required this.id,
    required this.nameMm,
    required this.nameEn,
    required this.descriptionMm,
    required this.tier,
    required this.goldPrice,
    required this.isFree,
    required this.isLimitedTime,
    required this.bannerColorHex,
  });

  factory VoicePackModel.fromJson(Map<String, dynamic> json) {
    return VoicePackModel(
      id: json['id'] as String,
      nameMm: json['nameMm'] as String,
      nameEn: json['nameEn'] as String? ?? '',
      descriptionMm: json['descriptionMm'] as String? ?? '',
      tier: json['tier'] as String? ?? 'FREE',
      goldPrice: (json['goldPrice'] as num?)?.toInt() ?? 0,
      isFree: json['isFree'] as bool? ?? false,
      isLimitedTime: json['isLimitedTime'] as bool? ?? false,
      bannerColorHex: json['bannerColorHex'] as String? ?? '#FFD700',
    );
  }
}

class PlayerVoiceSettingsModel {
  double masterVolume;
  double voiceStickerVolume;
  double sfxVolume;
  String preferredGender;
  bool autoVoiceEnabled;
  bool opponentVoiceEnabled;
  bool allowAutoTease;
  bool muteAll;
  int cooldownSeconds;
  Set<String> mutedPlayerIds;

  PlayerVoiceSettingsModel({
    this.masterVolume = 1.0,
    this.voiceStickerVolume = 1.0,
    this.sfxVolume = 0.9,
    this.preferredGender = 'MALE',
    this.autoVoiceEnabled = true,
    this.opponentVoiceEnabled = true,
    this.allowAutoTease = false,
    this.muteAll = false,
    this.cooldownSeconds = 6,
    Set<String>? mutedPlayerIds,
  }) : mutedPlayerIds = mutedPlayerIds ?? {};

  factory PlayerVoiceSettingsModel.fromJson(Map<String, dynamic> json) {
    return PlayerVoiceSettingsModel(
      masterVolume: (json['masterVolume'] as num?)?.toDouble() ?? 1.0,
      voiceStickerVolume: (json['voiceStickerVolume'] as num?)?.toDouble() ?? 1.0,
      sfxVolume: (json['sfxVolume'] as num?)?.toDouble() ?? 0.9,
      preferredGender: json['preferredGender'] as String? ?? 'MALE',
      autoVoiceEnabled: json['autoVoiceEnabled'] as bool? ?? true,
      opponentVoiceEnabled: json['opponentVoiceEnabled'] as bool? ?? true,
      allowAutoTease: json['allowAutoTease'] as bool? ?? false,
      muteAll: json['muteAll'] as bool? ?? false,
      cooldownSeconds: (json['cooldownSeconds'] as num?)?.toInt() ?? 6,
      mutedPlayerIds: ((json['mutedPlayerIds'] as List<dynamic>?) ?? [])
          .map((e) => e.toString())
          .toSet(),
    );
  }

  Map<String, dynamic> toJson() => {
        'masterVolume': masterVolume,
        'voiceStickerVolume': voiceStickerVolume,
        'sfxVolume': sfxVolume,
        'preferredGender': preferredGender,
        'autoVoiceEnabled': autoVoiceEnabled,
        'opponentVoiceEnabled': opponentVoiceEnabled,
        'allowAutoTease': allowAutoTease,
        'muteAll': muteAll,
        'cooldownSeconds': cooldownSeconds,
        'mutedPlayerIds': mutedPlayerIds.toList(),
      };
}

class ActiveStickerAnimationEvent {
  final String eventId;
  final String senderId;
  final String senderName;
  final VoiceStickerModel sticker;
  final String gender;
  final bool isAutoTrigger;
  final String triggerReason;

  const ActiveStickerAnimationEvent({
    required this.eventId,
    required this.senderId,
    required this.senderName,
    required this.sticker,
    required this.gender,
    required this.isAutoTrigger,
    required this.triggerReason,
  });
}

class FriendItemModel {
  final String userId;
  final String displayName;
  final bool isOnline;
  final String status;

  const FriendItemModel({
    required this.userId,
    required this.displayName,
    required this.isOnline,
    required this.status,
  });

  factory FriendItemModel.fromJson(Map<String, dynamic> json) {
    return FriendItemModel(
      userId: json['userId'] as String,
      displayName: json['displayName'] as String,
      isOnline: json['isOnline'] as bool? ?? false,
      status: json['status'] as String? ?? 'ACCEPTED',
    );
  }
}

class ChatMessageModel {
  final String id;
  final String roomId;
  final String senderId;
  final String senderName;
  final String msgType;
  final String content;
  final String? stickerId;
  final String timestamp;
  final String deliveryStatus;

  const ChatMessageModel({
    required this.id,
    required this.roomId,
    required this.senderId,
    required this.senderName,
    required this.msgType,
    required this.content,
    this.stickerId,
    required this.timestamp,
    required this.deliveryStatus,
  });

  factory ChatMessageModel.fromJson(Map<String, dynamic> json) {
    return ChatMessageModel(
      id: json['id'] as String,
      roomId: json['roomId'] as String? ?? 'GLOBAL',
      senderId: json['senderId'] as String,
      senderName: json['senderName'] as String? ?? 'Player',
      msgType: json['msgType'] as String? ?? 'TEXT',
      content: json['content'] as String? ?? '',
      stickerId: json['stickerId'] as String?,
      timestamp: json['timestamp'] as String? ?? '',
      deliveryStatus: json['deliveryStatus'] as String? ?? 'DELIVERED',
    );
  }
}
