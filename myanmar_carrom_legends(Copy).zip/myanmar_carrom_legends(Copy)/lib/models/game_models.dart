import 'package:flutter/material.dart';

enum BattleMode {
  duel1v1, // 2 Players: South (White) vs North (Black)
  team2v2, // 4 Players: South & North (White Team) vs East & West (Black Team)
}

enum CoinType {
  white,
  black,
  queen,
}

enum BoardSeat {
  south, // Player 1 (White)
  east,  // Player 2 (Black in 2v2)
  north, // Player 2 (Black in 1v1) OR Player 3 (White Teammate in 2v2)
  west,  // Player 4 (Black Teammate in 2v2)
}

enum QueenStatus {
  onBoard,
  pocketedPendingCover,
  coveredByWhite,
  coveredByBlack,
}

class PlayerSeatConfig {
  final int playerIndex;
  final String name;
  final BoardSeat seat;
  final CoinType assignedColor;
  final int teamId; // 0 = White Team, 1 = Black Team

  const PlayerSeatConfig({
    required this.playerIndex,
    required this.name,
    required this.seat,
    required this.assignedColor,
    required this.teamId,
  });
}

class TurnShotReport {
  bool strikerPocketed = false;
  bool queenPocketedThisShot = false;
  int whitePocketed = 0;
  int blackPocketed = 0;

  void reset() {
    strikerPocketed = false;
    queenPocketedThisShot = false;
    whitePocketed = 0;
    blackPocketed = 0;
  }
}

class TurnEvaluationResult {
  final bool keepTurn;
  final bool returnQueenToCenter;
  final int whitePenaltyCoinsToReturn;
  final int blackPenaltyCoinsToReturn;
  final bool boardFinished;
  final int? winningTeamId;
  final int pointsAwarded;
  final String burmeseText;

  const TurnEvaluationResult({
    required this.keepTurn,
    required this.returnQueenToCenter,
    this.whitePenaltyCoinsToReturn = 0,
    this.blackPenaltyCoinsToReturn = 0,
    this.boardFinished = false,
    this.winningTeamId,
    this.pointsAwarded = 0,
    required this.burmeseText,
  });
}

class MatchConfig {
  final BattleMode mode;
  final int targetPoints;
  final int maxBoards;

  const MatchConfig({
    required this.mode,
    this.targetPoints = 25,
    this.maxBoards = 8,
  });
}

class MatchStateSnapshot {
  final BattleMode mode;
  final int currentBoardNumber;
  final int whiteTeamScore;
  final int blackTeamScore;
  final int remainingWhiteCoins;
  final int remainingBlackCoins;
  final int whiteDebt;
  final int blackDebt;
  final QueenStatus queenStatus;
  final PlayerSeatConfig activePlayer;
  final String bannerMessage;
  final bool isStrikerMoving;
  final bool isPositioningConstrained;
  final bool matchComplete;
  final String? winnerAnnouncement;

  const MatchStateSnapshot({
    required this.mode,
    required this.currentBoardNumber,
    required this.whiteTeamScore,
    required this.blackTeamScore,
    required this.remainingWhiteCoins,
    required this.remainingBlackCoins,
    required this.whiteDebt,
    required this.blackDebt,
    required this.queenStatus,
    required this.activePlayer,
    required this.bannerMessage,
    required this.isStrikerMoving,
    required this.isPositioningConstrained,
    this.matchComplete = false,
    this.winnerAnnouncement,
  });

  Color get activeTeamColor =>
      activePlayer.assignedColor == CoinType.white
          ? const Color(0xFFF5F5DC)
          : const Color(0xFF2B2D42);
}
