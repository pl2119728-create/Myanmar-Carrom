import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import '../models/phase3_models.dart';
import '../services/voice_audio_engine.dart';

class MultiplayerService {
  final String serverUrl;
  late final String userId;
  late final String displayName;

  WebSocketChannel? _channel;
  final StreamController<Map<String, dynamic>> _eventController =
      StreamController<Map<String, dynamic>>.broadcast();

  final ValueNotifier<bool> isConnected = ValueNotifier<bool>(false);
  final ValueNotifier<String> statusMessage =
      ValueNotifier<String>('Server ချိတ်ဆက်ရန် အသင့်ရှိသည်');

  final ValueNotifier<int> goldBalance = ValueNotifier<int>(15000);
  final ValueNotifier<List<VoicePackModel>> voicePacks = ValueNotifier([]);
  final ValueNotifier<List<VoiceStickerModel>> voiceStickers = ValueNotifier([]);
  final ValueNotifier<Set<String>> ownedPackIds = ValueNotifier({'PACK_FREE_BASIC'});
  final ValueNotifier<Set<String>> ownedStickerIds = ValueNotifier({});
  final ValueNotifier<List<String>> equippedPackIds = ValueNotifier(['PACK_FREE_BASIC']);
  final ValueNotifier<List<String>> favoriteStickerIds = ValueNotifier([]);
  final ValueNotifier<PlayerVoiceSettingsModel> voiceSettings =
      ValueNotifier(PlayerVoiceSettingsModel());
  final ValueNotifier<ActiveStickerAnimationEvent?> activeStickerOverlay =
      ValueNotifier(null);
  final ValueNotifier<List<FriendItemModel>> friendsList = ValueNotifier([]);
  final ValueNotifier<List<ChatMessageModel>> chatMessages = ValueNotifier([]);

  Timer? _stickerOverlayTimer;

  Stream<Map<String, dynamic>> get events => _eventController.stream;

  MultiplayerService({
    this.serverUrl = 'ws://10.0.2.2:8080',
    String? customUserId,
    String? customName,
  }) {
    userId = customUserId ?? const Uuid().v4();
    displayName = customName ?? 'MM_Legend_${userId.substring(0, 4).toUpperCase()}';
    _seedOfflineDefaultCatalog();
  }

  void _seedOfflineDefaultCatalog() {
    final fallbackStickers = [
      _mk('STK_LAUGH_01', 'CAT_LAUGH', 'PACK_FREE_BASIC', 'ဟားဟားဟား', 'LAUGH_BOUNCE', true, 0),
      _mk('STK_LAUGH_02', 'CAT_LAUGH', 'PACK_FREE_BASIC', 'ကရော်ကရော်', 'LAUGH_BOUNCE', true, 0),
      _mk('STK_LAUGH_03', 'CAT_LAUGH', 'PACK_FUNNY', 'အဟက်ဟက်ဟက်', 'LAUGH_BOUNCE', false, 400),
      _mk('STK_LAUGH_04', 'CAT_LAUGH', 'PACK_FUNNY', 'ရယ်လိုက်ရတာကွာ', 'LAUGH_BOUNCE', false, 450),
      _mk('STK_LAUGH_05', 'CAT_LAUGH', 'PACK_MYANMAR_LEGEND', 'မင်းကိုကြည့်ပြီး ရယ်နေရတယ်', 'LAUGH_BOUNCE', false, 600),
      _mk('STK_TEASE_01', 'CAT_TEASE', 'PACK_FREE_BASIC', 'လက်ကန်းကြီး လက်ကန်းကြီး', 'TEASE_WINK', true, 0),
      _mk('STK_TEASE_02', 'CAT_TEASE', 'PACK_FUNNY', 'ဘာမှမတတ်ဘူးလား', 'TEASE_WINK', false, 450),
      _mk('STK_TEASE_03', 'CAT_TEASE', 'PACK_FUNNY', 'အဲဒါကြီးလား', 'TEASE_WINK', false, 450),
      _mk('STK_TEASE_04', 'CAT_TEASE', 'PACK_MYANMAR_LEGEND', 'မင်းကတော့ လုံးဝပဲ', 'TEASE_WINK', false, 550),
      _mk('STK_TEASE_05', 'CAT_TEASE', 'PACK_FUNNY', 'ထပ်ပစ်ကြည့်လေ', 'TEASE_WINK', false, 400),
      _mk('STK_WIN_01', 'CAT_WIN', 'PACK_FREE_BASIC', 'ငါနိုင်ပြီဟေ့', 'VICTORY_DANCE', true, 0),
      _mk('STK_WIN_02', 'CAT_WIN', 'PACK_PRO', 'ပြောထားတယ်လေ', 'VICTORY_DANCE', false, 500),
      _mk('STK_WIN_03', 'CAT_WIN', 'PACK_PRO', 'ဘယ်သူနိုင်သွားလဲ', 'VICTORY_DANCE', false, 500),
      _mk('STK_WIN_04', 'CAT_WIN', 'PACK_PRO', 'ဒါမှ ငါ့စတိုင်', 'VICTORY_DANCE', false, 550),
      _mk('STK_WIN_05', 'CAT_WIN', 'PACK_MYANMAR_LEGEND', 'ဒီပွဲတော့ ငါ့ပွဲပဲ', 'VICTORY_DANCE', false, 650),
      _mk('STK_LOSE_01', 'CAT_LOSE', 'PACK_FREE_BASIC', 'အောင်မလေးကွာ', 'CRY_DROP', true, 0),
      _mk('STK_LOSE_02', 'CAT_LOSE', 'PACK_FUNNY', 'မဖြစ်နိုင်ဘူးကွာ', 'CRY_DROP', false, 400),
      _mk('STK_LOSE_03', 'CAT_LOSE', 'PACK_FREE_BASIC', 'နောက်တစ်ပွဲလာခဲ့', 'CRY_DROP', true, 0),
      _mk('STK_LOSE_04', 'CAT_LOSE', 'PACK_FUNNY', 'ကံမကောင်းလိုက်တာ', 'CRY_DROP', false, 400),
      _mk('STK_LOSE_05', 'CAT_LOSE', 'PACK_PRO', 'ပြန်ကစားမယ်', 'CRY_DROP', false, 450),
      _mk('STK_CHAL_01', 'CAT_CHALLENGE', 'PACK_FREE_BASIC', 'လာခဲ့လေကွာ', 'CHALLENGE_FIRE', true, 0),
      _mk('STK_CHAL_02', 'CAT_CHALLENGE', 'PACK_MYANMAR_LEGEND', 'မင်းနဲ့ငါ တွေ့ကြသေးတာပေါ့', 'CHALLENGE_FIRE', false, 600),
      _mk('STK_CHAL_03', 'CAT_CHALLENGE', 'PACK_PRO', 'စောင့်ကြည့်နေ', 'CHALLENGE_FIRE', false, 500),
      _mk('STK_CHAL_04', 'CAT_CHALLENGE', 'PACK_MYANMAR_LEGEND', 'တကယ်ပြိုင်ကြမယ်', 'CHALLENGE_FIRE', false, 550),
      _mk('STK_CHAL_05', 'CAT_CHALLENGE', 'PACK_FREE_BASIC', 'အဆင်သင့်ပဲလား', 'CHALLENGE_FIRE', true, 0),
      _mk('STK_CARROM_01', 'CAT_CARROM', 'PACK_FREE_BASIC', 'Queen ရပြီဟေ့', 'QUEEN_CROWN', true, 0),
      _mk('STK_CARROM_02', 'CAT_CARROM', 'PACK_PRO', 'အဲဒီအပြားလေးတော့ ဝင်သွားပြီ', 'QUEEN_CROWN', false, 500),
      _mk('STK_CARROM_03', 'CAT_CARROM', 'PACK_FUNNY', 'လွဲသွားပြန်ပြီ', 'CRY_DROP', false, 450),
      _mk('STK_CARROM_04', 'CAT_CARROM', 'PACK_SPECIAL_EVENT', 'Striker ပြန်ဝင်သွားပြီ', 'SHOCK_POP', false, 550),
      _mk('STK_CARROM_05', 'CAT_CARROM', 'PACK_MYANMAR_LEGEND', 'အပြားတွေ အကုန်ရှင်းတော့မယ်', 'QUEEN_CROWN', false, 650),
      _mk('STK_REACT_01', 'CAT_REACTION', 'PACK_FREE_BASIC', 'အမလေး', 'SHOCK_POP', true, 0),
      _mk('STK_REACT_02', 'CAT_REACTION', 'PACK_SPECIAL_EVENT', 'ဟာကွာ', 'SHOCK_POP', false, 400),
      _mk('STK_REACT_03', 'CAT_REACTION', 'PACK_SPECIAL_EVENT', 'ဝိုး', 'SHOCK_POP', false, 450),
      _mk('STK_REACT_04', 'CAT_REACTION', 'PACK_PRO', 'မိုက်တယ်ဟေ့', 'VICTORY_DANCE', false, 500),
      _mk('STK_REACT_05', 'CAT_REACTION', 'PACK_SPECIAL_EVENT', 'မယုံနိုင်ဘူး', 'SHOCK_POP', false, 500),
    ];

    voiceStickers.value = fallbackStickers;
    ownedStickerIds.value = fallbackStickers
        .where((s) => s.isFreeDefault)
        .map((s) => s.id)
        .toSet();
    favoriteStickerIds.value = [
      'STK_LAUGH_01',
      'STK_LAUGH_02',
      'STK_TEASE_01',
      'STK_WIN_01',
      'STK_CARROM_01',
      'STK_CHAL_01',
    ];
    voicePacks.value = const [
      VoicePackModel(
        id: 'PACK_FREE_BASIC',
        nameMm: 'အခြေခံ အခမဲ့အသံထုပ် (Free Pack)',
        nameEn: 'Free Basic Pack',
        descriptionMm: 'ကစားသမားတိုင်း အခမဲ့ရရှိသော အခြေခံ မြန်မာအသံ စတစ်ကာ ၁၀ ခု',
        tier: 'FREE',
        goldPrice: 0,
        isFree: true,
        isLimitedTime: false,
        bannerColorHex: '#00E676',
      ),
      VoicePackModel(
        id: 'PACK_FUNNY',
        nameMm: 'ဟာသနှင့် စနောက်သံထုပ် (Funny Pack)',
        nameEn: 'Funny Pack',
        descriptionMm: 'ရယ်မောသံနှင့် စနောက်သံ Animation အထူးစတစ်ကာများ',
        tier: 'FUNNY',
        goldPrice: 1800,
        isFree: false,
        isLimitedTime: false,
        bannerColorHex: '#FFB703',
      ),
      VoicePackModel(
        id: 'PACK_PRO',
        nameMm: 'ပရို အောင်ပွဲခံအသံထုပ် (Pro Pack)',
        nameEn: 'Pro Pack',
        descriptionMm: 'Queen ဝင်ချိန်နှင့် အနိုင်ရချိန် အထူးအောင်ပွဲခံ အသံစတစ်ကာများ',
        tier: 'PRO',
        goldPrice: 2800,
        isFree: false,
        isLimitedTime: false,
        bannerColorHex: '#00B4D8',
      ),
      VoicePackModel(
        id: 'PACK_MYANMAR_LEGEND',
        nameMm: 'မြန်မာ့ဇယ်ခုံဘုရင် အသံထုပ် (Legend Pack)',
        nameEn: 'Myanmar Legend Pack',
        descriptionMm: 'မြန်မာ့ရိုးရာ စိန်ခေါ်သံနှင့် ဟာသစတိုင် အထူးရှားပါး အသံစုံတွဲ',
        tier: 'MYANMAR_LEGEND',
        goldPrice: 4500,
        isFree: false,
        isLimitedTime: false,
        bannerColorHex: '#FFD700',
      ),
      VoicePackModel(
        id: 'PACK_SPECIAL_EVENT',
        nameMm: 'ပွဲတော်အထူး ကန့်သတ်အသံထုပ် (Event Pack)',
        nameEn: 'Special Event Pack',
        descriptionMm: 'အချိန်ကန့်သတ် ပွဲတော်အထူး အသံနှင့် Animation စတစ်ကာများ',
        tier: 'SPECIAL_EVENT',
        goldPrice: 3200,
        isFree: false,
        isLimitedTime: true,
        bannerColorHex: '#FF2A85',
      ),
    ];
  }

  VoiceStickerModel _mk(
    String id,
    String cat,
    String pack,
    String mm,
    String anim,
    bool free,
    int price,
  ) {
    return VoiceStickerModel(
      id: id,
      categoryId: cat,
      packId: pack,
      burmeseText: mm,
      phoneticText: mm,
      cdnAudioMale: '',
      cdnAudioFemale: '',
      animationType: anim,
      autoTrigger: 'MANUAL_ONLY',
      goldPrice: price,
      isFreeDefault: free,
      pitchMale: 1.04,
      pitchFemale: 1.32,
      rate: 0.92,
    );
  }

  void connect() {
    try {
      statusMessage.value = 'Server သို့ ချိတ်ဆက်နေသည်...';
      _channel = WebSocketChannel.connect(Uri.parse(serverUrl));
      isConnected.value = true;

      _channel!.stream.listen(
        (raw) {
          final data = jsonDecode(raw as String) as Map<String, dynamic>;
          _handleIncomingMessage(data);
        },
        onDone: () {
          isConnected.value = false;
          statusMessage.value = 'ချိတ်ဆက်မှု ပြတ်တောက်သွားသည် — Local Mode ဖြင့် ကစားနိုင်သည်';
        },
        onError: (_) {
          isConnected.value = false;
          statusMessage.value = 'Offline Mode Ready (35 Myanmar Voice Stickers Loaded)';
        },
      );

      send('AUTH_GUEST', {
        'userId': userId,
        'displayName': displayName,
      });
    } catch (_) {
      isConnected.value = false;
    }
  }

  void _applyPhase3Bundle(Map<String, dynamic> b) {
    goldBalance.value = (b['goldBalance'] as num?)?.toInt() ?? goldBalance.value;
    if (b['packs'] != null) {
      voicePacks.value = (b['packs'] as List<dynamic>)
          .map((e) => VoicePackModel.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    if (b['stickers'] != null) {
      voiceStickers.value = (b['stickers'] as List<dynamic>)
          .map((e) => VoiceStickerModel.fromJson(e as Map<String, dynamic>))
          .toList();
    }
    if (b['ownedPackIds'] != null) {
      ownedPackIds.value =
          (b['ownedPackIds'] as List<dynamic>).map((e) => e.toString()).toSet();
    }
    if (b['ownedStickerIds'] != null) {
      ownedStickerIds.value =
          (b['ownedStickerIds'] as List<dynamic>).map((e) => e.toString()).toSet();
    }
    if (b['equippedPackIds'] != null) {
      equippedPackIds.value =
          (b['equippedPackIds'] as List<dynamic>).map((e) => e.toString()).toList();
    }
    if (b['favoriteStickerIds'] != null) {
      favoriteStickerIds.value =
          (b['favoriteStickerIds'] as List<dynamic>).map((e) => e.toString()).toList();
    }
    if (b['settings'] != null) {
      voiceSettings.value = PlayerVoiceSettingsModel.fromJson(
        b['settings'] as Map<String, dynamic>,
      );
    }
  }

  void _handleIncomingMessage(Map<String, dynamic> msg) {
    final type = msg['type'] as String? ?? '';
    switch (type) {
      case 'AUTH_SUCCESS':
        statusMessage.value = 'အွန်လိုင်း ချိတ်ဆက်ပြီး (${msg['displayName']})';
        if (msg['phase3Bundle'] != null) {
          _applyPhase3Bundle(msg['phase3Bundle'] as Map<String, dynamic>);
        }
        if (msg['friends'] != null) {
          friendsList.value = (msg['friends'] as List<dynamic>)
              .map((e) => FriendItemModel.fromJson(e as Map<String, dynamic>))
              .toList();
        }
        break;

      case 'VOICE_STICKER_EVENT':
        final stkMap = msg['sticker'] as Map<String, dynamic>;
        final sticker = VoiceStickerModel.fromJson(stkMap);
        final senderId = msg['senderId'] as String? ?? '';
        final senderName = msg['senderName'] as String? ?? 'Player';
        final gender = msg['gender'] as String? ?? 'MALE';
        final eventId = msg['eventId'] as String? ?? const Uuid().v4();
        final isAuto = msg['isAutoTrigger'] as bool? ?? false;
        final reason = msg['triggerReason'] as String? ?? 'MANUAL';

        _triggerOverlayAndAudio(
          ActiveStickerAnimationEvent(
            eventId: eventId,
            senderId: senderId,
            senderName: senderName,
            sticker: sticker,
            gender: gender,
            isAutoTrigger: isAuto,
            triggerReason: reason,
          ),
        );
        break;

      case 'VOICE_PACK_PURCHASE_RESULT':
      case 'BUNDLE_SYNC':
        if (msg['bundle'] != null) {
          _applyPhase3Bundle(msg['bundle'] as Map<String, dynamic>);
        }
        break;

      case 'FAVORITES_UPDATED':
        favoriteStickerIds.value = (msg['favoriteStickerIds'] as List<dynamic>)
            .map((e) => e.toString())
            .toList();
        break;

      case 'VOICE_SETTINGS_UPDATED':
        voiceSettings.value = PlayerVoiceSettingsModel.fromJson(
          msg['settings'] as Map<String, dynamic>,
        );
        break;

      case 'CATALOG_UPDATED':
        if (msg['newSticker'] != null) {
          final added = VoiceStickerModel.fromJson(
            msg['newSticker'] as Map<String, dynamic>,
          );
          final list = [...voiceStickers.value.where((s) => s.id != added.id), added];
          voiceStickers.value = list;
        }
        if (msg['newPack'] != null) {
          final addedPack = VoicePackModel.fromJson(
            msg['newPack'] as Map<String, dynamic>,
          );
          final list = [...voicePacks.value.where((p) => p.id != addedPack.id), addedPack];
          voicePacks.value = list;
        }
        break;

      case 'FRIENDS_UPDATED':
      case 'FRIEND_REQUEST_RECEIVED':
        if (msg['friends'] != null) {
          friendsList.value = (msg['friends'] as List<dynamic>)
              .map((e) => FriendItemModel.fromJson(e as Map<String, dynamic>))
              .toList();
        }
        break;

      case 'CHAT_MESSAGE_EVENT':
        final chatMsg = ChatMessageModel.fromJson(
          msg['message'] as Map<String, dynamic>,
        );
        chatMessages.value = [...chatMessages.value, chatMsg];
        break;
    }
    _eventController.add(msg);
  }

  void _triggerOverlayAndAudio(ActiveStickerAnimationEvent ev) {
    if (voiceSettings.value.muteAll) return;
    if (ev.senderId != userId &&
        (!voiceSettings.value.opponentVoiceEnabled ||
            voiceSettings.value.mutedPlayerIds.contains(ev.senderId))) {
      return;
    }

    activeStickerOverlay.value = ev;
    _stickerOverlayTimer?.cancel();
    _stickerOverlayTimer = Timer(const Duration(milliseconds: 2800), () {
      activeStickerOverlay.value = null;
    });

    VoiceAudioEngine.instance.playStickerAudio(
      sticker: ev.sticker,
      settings: voiceSettings.value,
      senderId: ev.senderId,
      myUserId: userId,
      eventId: ev.eventId,
      overrideGender: ev.gender,
    );
  }

  void triggerVoiceSticker(VoiceStickerModel sticker, {bool isAuto = false, String reason = 'MANUAL'}) {
    if (isConnected.value) {
      send('SEND_VOICE_STICKER', {'stickerId': sticker.id});
    } else {
      _triggerOverlayAndAudio(
        ActiveStickerAnimationEvent(
          eventId: const Uuid().v4(),
          senderId: userId,
          senderName: displayName,
          sticker: sticker,
          gender: voiceSettings.value.preferredGender,
          isAutoTrigger: isAuto,
          triggerReason: reason,
        ),
      );
    }
  }

  void purchasePack(String packId) {
    if (isConnected.value) {
      send('PURCHASE_VOICE_PACK', {'packId': packId});
      return;
    }
    final pack = voicePacks.value.firstWhere((p) => p.id == packId);
    if (goldBalance.value >= pack.goldPrice && !ownedPackIds.value.contains(packId)) {
      goldBalance.value -= pack.goldPrice;
      ownedPackIds.value = {...ownedPackIds.value, packId};
      final newlyUnlocked = voiceStickers.value
          .where((s) => s.packId == packId)
          .map((s) => s.id);
      ownedStickerIds.value = {...ownedStickerIds.value, ...newlyUnlocked};
    }
  }

  void toggleFavoriteSticker(String stickerId) {
    if (isConnected.value) {
      send('TOGGLE_FAVORITE_STICKER', {'stickerId': stickerId});
      return;
    }
    final list = [...favoriteStickerIds.value];
    if (list.contains(stickerId)) {
      list.remove(stickerId);
    } else {
      if (list.length >= 6) list.removeAt(0);
      list.add(stickerId);
    }
    favoriteStickerIds.value = list;
  }

  void saveVoiceSettings(PlayerVoiceSettingsModel updated) {
    voiceSettings.value = updated;
    if (isConnected.value) {
      send('UPDATE_VOICE_SETTINGS', {'settings': updated.toJson()});
    }
  }

  void sendChatMessage(String content, {String msgType = 'TEXT', String? targetUserId}) {
    if (isConnected.value) {
      send('SEND_CHAT_MESSAGE', {
        'msgType': msgType,
        'content': content,
        if (targetUserId != null) 'targetUserId': targetUserId,
      });
    } else {
      chatMessages.value = [
        ...chatMessages.value,
        ChatMessageModel(
          id: const Uuid().v4(),
          roomId: 'LOCAL',
          senderId: userId,
          senderName: displayName,
          msgType: msgType,
          content: content,
          timestamp: DateTime.now().toIso8601String(),
          deliveryStatus: 'DELIVERED',
        ),
      ];
    }
  }

  void queueMatchmaking({required bool isTeam2v2}) =>
      send('QUEUE_MATCHMAKING', {'mode': isTeam2v2 ? 'TEAM_2V2' : 'DUEL_1V1'});

  void createPrivateRoom({required bool isTeam2v2}) =>
      send('CREATE_PRIVATE_ROOM', {'mode': isTeam2v2 ? 'TEAM_2V2' : 'DUEL_1V1'});

  void joinPrivateRoom(String roomCode) =>
      send('JOIN_PRIVATE_ROOM', {'roomCode': roomCode});

  void sendStrikerSlide(double ratio) => send('STRIKER_SLIDE', {'ratio': ratio});

  void sendExecuteShot({
    required double sliderRatio,
    required double dragX,
    required double dragY,
  }) {
    send('EXECUTE_SHOT', {
      'shotId': const Uuid().v4(),
      'sliderRatio': sliderRatio,
      'dragX': dragX,
      'dragY': dragY,
    });
  }

  void send(String type, Map<String, dynamic> payload) {
    if (_channel != null && isConnected.value) {
      _channel!.sink.add(jsonEncode({'type': type, ...payload}));
    }
  }

  void dispose() {
    _stickerOverlayTimer?.cancel();
    _channel?.sink.close();
    _eventController.close();
  }
}
